/*
 * tuning.h — 全部可调参数
 *
 * 修改此文件后重新编译烧录即可，无需改动其他文件。
 *===========================================================================*/

#ifndef TUNING_H
#define TUNING_H

/* ========== 控制周期 ========== */
#define CTRL_PERIOD_MS          10

/* ---------- 速度 PID（内环） ---------- */
#define BASE_SPEED_TARGET       2.5      /* 目标速度（编码器 count / 控制周期） */
#define SPEED_KP                5.0f
#define SPEED_KI                0.5f
#define SPEED_KD                0.0f
#define SPEED_MAX_I             600.0f
#define SPEED_OUT_MAX           900.0f

/* ---------- 位置同步 PID（外环，走直线用） ---------- */
#define SYNC_KP                 0.0f    /* 0=关闭，走直线时设为 0.02f */
#define SYNC_KI                 0.0f
#define SYNC_KD                 0.0f
#define SYNC_MAX_I              100.0f
#define SYNC_OUT_MAX            150.0f

/* ---------- PWM ---------- */
#define PWM_MIN_START           100

/* ================================================================
 * 循迹参数（灰度传感器）
 * ================================================================ */

/* ---------- 循迹 ---------- */
#define TRACK_SPEED             400     /* 循迹基础速度 PWM (0~1000) */

/* ---------- 按钮（板载 S1 = PA18） ---------- */
#define BUTTON_PORT             GPIOA
#define BUTTON_PINS             DL_GPIO_PIN_18
#define BUTTON_PINCM            IOMUX_PINCM40

/* ---------- 灰度传感器黑白阈值（用于 line_follower.c，gray.c 不用） ---------- */
#define LF_BLACK_THRESHOLD       800    /* 低于此值 = 黑线 */
#define LF_WHITE_THRESHOLD      2500    /* 高于此值 = 白底 */

/* 循迹 PID */
#define LF_KP                   0.5f    /* 比例：转向响应快慢 */
#define LF_KI                   0.02f   /* 积分：消除稳态偏差 */
#define LF_KD                   0.1f    /* 微分：抑制振荡 */
#define LF_I_MAX                200.0f  /* 积分限幅 */

/* 循迹基础速度（PWM 0~1000） */
#define LF_BASE_SPEED           500

#endif /* TUNING_H */
