# FIXED

lib/track.o: ../lib/track.c ../lib/track.h ../lib/gray.h \
 ../lib/car_control.h C:/Users/23958/workspace_ccstheia/empty/tuning.h
../lib/track.h:
../lib/gray.h:
../lib/car_control.h:
C:/Users/23958/workspace_ccstheia/empty/tuning.h:
