################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../lib/car_control.c \
../lib/gray.c \
../lib/line_follower.c \
../lib/track.c 

C_DEPS += \
./lib/car_control.d \
./lib/gray.d \
./lib/line_follower.d \
./lib/track.d 

OBJS += \
./lib/car_control.o \
./lib/gray.o \
./lib/line_follower.o \
./lib/track.o 

OBJS__QUOTED += \
"lib\car_control.o" \
"lib\gray.o" \
"lib\line_follower.o" \
"lib\track.o" 

C_DEPS__QUOTED += \
"lib\car_control.d" \
"lib\gray.d" \
"lib\line_follower.d" \
"lib\track.d" 

C_SRCS__QUOTED += \
"../lib/car_control.c" \
"../lib/gray.c" \
"../lib/line_follower.c" \
"../lib/track.c" 


