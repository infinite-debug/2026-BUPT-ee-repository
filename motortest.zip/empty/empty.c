/*
 * 诊断程序 v2
 *   测试 1: 上电 2 秒 → 电机转（验证硬件）
 *   测试 2: 按 S1     → 电机转（验证按钮）
 *   测试 3: 按 S1     → 灰度传感器直读模式
 *           根据传感器 X3~X6 实时控制电机，可直接观察传感器是否工作
 */
#include "ti_msp_dl_config.h"
#include "tuning.h"
#include "lib/car_control.h"
#include "lib/gray.h"
#include <ti/devices/msp/msp.h>

/* ---- 按钮 ---- */
static void Btn_Init(void)
{
    DL_GPIO_initDigitalInputFeatures(BUTTON_PINCM,
        DL_GPIO_INVERSION_DISABLE,
        DL_GPIO_RESISTOR_PULL_UP,
        DL_GPIO_HYSTERESIS_ENABLE,
        DL_GPIO_WAKEUP_DISABLE);
}
static uint8_t Btn_Pressed(void)
{
    return (DL_GPIO_readPins(BUTTON_PORT, BUTTON_PINS) == 0U);
}
static void Btn_Wait(void)
{
    while (!Btn_Pressed()) {}
    delay_cycles(320000);
    while (Btn_Pressed()) {}
    delay_cycles(320000);
}

static void Wait(uint32_t ms)
{
    uint32_t i;
    for (i = 0; i < ms; i++) delay_cycles(32000);
}

/* ---- 电机短转 ---- */
static void Blip(void)
{
    Car_SetManualMode(1);
    Car_Enable();
    Car_SetMotorPWM(400, 400);
    Wait(500);
    Car_SetMotorPWM(0, 0);
    Car_Disable();
    Car_SetManualMode(0);
}

/*===========================================================================
 * main
 *===========================================================================*/
int main(void)
{
    Car_Init();
    Gray_Init();
    Btn_Init();

    /* 测试 1 */
    Wait(2000);
    Blip();

    /* 测试 2 */
    Btn_Wait();
    Blip();

    /* 测试 3: 灰度传感器直读 —— 用电机动作反馈传感器状态 */
    Btn_Wait();
    Car_SetManualMode(1);
    Car_Enable();

    while (1) {
        uint8_t raw = Gray_ReadLevels();  /* bits 0~3 → X3~X6 */

        /*
         * 根据传感器状态直接控电机：
         *   bit=1 (HIGH, 黑线) 时对应位置检测到线
         */
        uint8_t x3 = (raw >> 0) & 1;  /* 最左 */
        uint8_t x4 = (raw >> 1) & 1;
        uint8_t x5 = (raw >> 2) & 1;
        uint8_t x6 = (raw >> 3) & 1;  /* 最右 */

        uint8_t left_see  = x3 | x4;  /* 左侧两路有黑线 */
        uint8_t right_see = x5 | x6;  /* 右侧两路有黑线 */

        if (left_see && right_see) {
            Car_SetMotorPWM(300, 300);           /* 全有 → 直行 */
        } else if (left_see) {
            Car_SetMotorPWM(150, 300);           /* 偏左 → 左转 */
        } else if (right_see) {
            Car_SetMotorPWM(300, 150);           /* 偏右 → 右转 */
        } else {
            Car_SetMotorPWM(0, 0);               /* 全无 → 停车 */
        }

        if (Btn_Pressed()) {
            Car_SetMotorPWM(0, 0);
            Car_Disable();
            Car_SetManualMode(0);
            break;
        }
    }

    while (1) {}
}
