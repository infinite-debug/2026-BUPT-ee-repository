/*
 * car_control.c — 小车运动控制实现
 *
 * 将 empty.c 中的电机驱动 + 编码器 + PID 控制封装为独立模块。
 */
#include "ti_msp_dl_config.h"
#include "tuning.h"
#include "car_control.h"
#include <ti/devices/msp/msp.h>

/*===========================================================================
 * 引脚别名
 *===========================================================================*/
#define AIN1_PORT       GPIO_MOTOR_PORT
#define AIN1_PINS       GPIO_MOTOR_AIN1_PIN
#define AIN2_PORT       GPIO_MOTOR_PORT
#define AIN2_PINS       GPIO_MOTOR_AIN2_PIN
#define BIN1_PORT       GPIO_MOTOR_PORT
#define BIN1_PINS       GPIO_MOTOR_BIN1_PIN
#define BIN2_PORT       GPIO_MOTOR_PORT
#define BIN2_PINS       GPIO_MOTOR_BIN2_PIN
#define STBY_PORT       GPIO_MOTOR_PORT
#define STBY_PINS       GPIO_MOTOR_STBY_PIN

#define PWM_PERIOD      1000U
#define PWM_MAX_DUTY    1000U

#define ENC_L_PORT      GPIOA
#define ENC_L_PINS      DL_GPIO_PIN_12
#define ENC_L_PINCM     IOMUX_PINCM34
#define ENC_R_PORT      GPIOA
#define ENC_R_PINS      DL_GPIO_PIN_13
#define ENC_R_PINCM     IOMUX_PINCM35

/*===========================================================================
 * PID 数据结构
 *===========================================================================*/
typedef struct {
    float Kp, Ki, Kd;
    float setpoint;
    float integral;
    float prev_error;
    float out_min, out_max;
    float i_max;
} PID_t;

/*===========================================================================
 * 全局状态
 *===========================================================================*/
static volatile int32_t  g_enc_left  = 0;
static volatile int32_t  g_enc_right = 0;
static volatile uint32_t g_tick_10ms = 0;

static int32_t  g_enc_left_prev  = 0;
static int32_t  g_enc_right_prev = 0;
static float    g_speed_left     = 0;
static float    g_speed_right    = 0;

static PID_t g_spid_left;
static PID_t g_spid_right;
static PID_t g_sync_pid;

static float    g_base_speed   = BASE_SPEED_TARGET;
static float    g_last_left_pwm  = 0;
static float    g_last_right_pwm = 0;
static uint8_t  g_sync_enabled   = 1;
static uint8_t  g_manual_mode    = 0;  /* 1 = 外部控制 PWM，速度环停写 */

/*===========================================================================
 * PID 计算
 *===========================================================================*/
static void PID_Init(PID_t *pid, float kp, float ki, float kd,
                     float out_min, float out_max, float i_max)
{
    pid->Kp = kp; pid->Ki = ki; pid->Kd = kd;
    pid->setpoint = 0; pid->integral = 0; pid->prev_error = 0;
    pid->out_min = out_min; pid->out_max = out_max; pid->i_max = i_max;
}

static float PID_Compute(PID_t *pid, float measured)
{
    float error = pid->setpoint - measured;
    float p_out = pid->Kp * error;
    pid->integral += error;
    if (pid->integral >  pid->i_max) pid->integral =  pid->i_max;
    if (pid->integral < -pid->i_max) pid->integral = -pid->i_max;
    float i_out = pid->Ki * pid->integral;
    float d_out = pid->Kd * (error - pid->prev_error);
    pid->prev_error = error;
    float output = p_out + i_out + d_out;
    if (output > pid->out_max) output = pid->out_max;
    if (output < pid->out_min) output = pid->out_min;
    return output;
}

static void PID_Reset(PID_t *pid, float setpoint)
{
    pid->setpoint   = setpoint;
    pid->integral   = 0;
    pid->prev_error = 0;
}

/*===========================================================================
 * 底层电机控制
 *===========================================================================*/
static void MotorA_SetDir(uint8_t fwd)
{
    if (fwd) {
        DL_GPIO_setPins(AIN1_PORT, AIN1_PINS);
        DL_GPIO_clearPins(AIN2_PORT, AIN2_PINS);
    } else {
        DL_GPIO_clearPins(AIN1_PORT, AIN1_PINS);
        DL_GPIO_setPins(AIN2_PORT, AIN2_PINS);
    }
}

static void MotorB_SetDir(uint8_t fwd)
{
    if (fwd) {
        DL_GPIO_setPins(BIN1_PORT, BIN1_PINS);
        DL_GPIO_clearPins(BIN2_PORT, BIN2_PINS);
    } else {
        DL_GPIO_clearPins(BIN1_PORT, BIN1_PINS);
        DL_GPIO_setPins(BIN2_PORT, BIN2_PINS);
    }
}

static void MotorA_SetPWM(uint16_t duty)
{
    if (duty > PWM_MAX_DUTY) duty = PWM_MAX_DUTY;
    DL_TimerG_setCaptureCompareValue(PWM_0_INST,
        PWM_PERIOD - duty, DL_TIMER_CC_0_INDEX);
}

static void MotorB_SetPWM(uint16_t duty)
{
    if (duty > PWM_MAX_DUTY) duty = PWM_MAX_DUTY;
    DL_TimerG_setCaptureCompareValue(PWM_0_INST,
        PWM_PERIOD - duty, DL_TIMER_CC_1_INDEX);
}

/*===========================================================================
 * 编码器初始化
 *===========================================================================*/
static void Encoder_Init(void)
{
    DL_GPIO_initDigitalInputFeatures(ENC_L_PINCM,
        DL_GPIO_INVERSION_DISABLE, DL_GPIO_RESISTOR_PULL_UP,
        DL_GPIO_HYSTERESIS_DISABLE, DL_GPIO_WAKEUP_DISABLE);
    DL_GPIO_initDigitalInputFeatures(ENC_R_PINCM,
        DL_GPIO_INVERSION_DISABLE, DL_GPIO_RESISTOR_PULL_UP,
        DL_GPIO_HYSTERESIS_DISABLE, DL_GPIO_WAKEUP_DISABLE);

    DL_GPIO_setLowerPinsPolarity(ENC_L_PORT,
        DL_GPIO_PIN_12_EDGE_RISE_FALL | DL_GPIO_PIN_13_EDGE_RISE_FALL);

    DL_GPIO_clearInterruptStatus(ENC_L_PORT, ENC_L_PINS);
    DL_GPIO_clearInterruptStatus(ENC_R_PORT, ENC_R_PINS);
    DL_GPIO_enableInterrupt(ENC_L_PORT, ENC_L_PINS);
    DL_GPIO_enableInterrupt(ENC_R_PORT, ENC_R_PINS);
    NVIC_EnableIRQ(GPIOA_INT_IRQn);
}

/*===========================================================================
 * SysTick
 *===========================================================================*/
static void SysTick_Init(void)
{
    SysTick->LOAD = (CPUCLK_FREQ / 1000) * CTRL_PERIOD_MS - 1;
    SysTick->VAL  = 0;
    SysTick->CTRL = SysTick_CTRL_CLKSOURCE_Msk |
                    SysTick_CTRL_TICKINT_Msk   |
                    SysTick_CTRL_ENABLE_Msk;
    NVIC_SetPriority(SysTick_IRQn, 0);
}

/*===========================================================================
 * 控制循环
 *===========================================================================*/
static void ControlLoop_10ms(void)
{
    int32_t left_now, right_now;
    __disable_irq();
    left_now  = g_enc_left;
    right_now = g_enc_right;
    __enable_irq();

    g_speed_left  = (float)(left_now  - g_enc_left_prev);
    g_speed_right = (float)(right_now - g_enc_right_prev);
    g_enc_left_prev  = left_now;
    g_enc_right_prev = right_now;

    /* 外环：位置同步 */
    float sync_out = 0;
    if (g_sync_enabled) {
        sync_out = PID_Compute(&g_sync_pid, (float)(left_now - right_now));
    }

    /* 内环：左轮速度 */
    g_spid_left.setpoint = (float)g_base_speed - sync_out;
    if (g_spid_left.setpoint < 0) g_spid_left.setpoint = 0;
    float lpwm = PID_Compute(&g_spid_left, g_speed_left);

    /* 内环：右轮速度 */
    g_spid_right.setpoint = (float)g_base_speed + sync_out;
    if (g_spid_right.setpoint < 0) g_spid_right.setpoint = 0;
    float rpwm = PID_Compute(&g_spid_right, g_speed_right);

    g_last_left_pwm  = lpwm;
    g_last_right_pwm = rpwm;

    if (!g_manual_mode) {
        MotorA_SetPWM((uint16_t)lpwm);
        MotorB_SetPWM((uint16_t)rpwm);
    }
}

/*===========================================================================
 * 中断
 *===========================================================================*/
void GROUP1_IRQHandler(void)
{
    uint32_t status = DL_GPIO_getEnabledInterruptStatus(GPIOA,
                         ENC_L_PINS | ENC_R_PINS);
    if (status & ENC_L_PINS) {
        DL_GPIO_clearInterruptStatus(GPIOA, ENC_L_PINS);
        g_enc_left++;
    }
    if (status & ENC_R_PINS) {
        DL_GPIO_clearInterruptStatus(GPIOA, ENC_R_PINS);
        g_enc_right++;
    }
}

void SysTick_Handler(void)
{
    g_tick_10ms++;
    ControlLoop_10ms();
}

/*===========================================================================
 * 公开 API
 *===========================================================================*/
void Car_Init(void)
{
    SYSCFG_DL_init();
    Encoder_Init();
    SysTick_Init();

    MotorA_SetDir(1);
    MotorB_SetDir(1);

    PID_Init(&g_spid_left,  SPEED_KP, SPEED_KI, SPEED_KD,
             0, SPEED_OUT_MAX, SPEED_MAX_I);
    PID_Init(&g_spid_right, SPEED_KP, SPEED_KI, SPEED_KD,
             0, SPEED_OUT_MAX, SPEED_MAX_I);
    PID_Init(&g_sync_pid,   SYNC_KP,  SYNC_KI,  SYNC_KD,
             -SYNC_OUT_MAX, SYNC_OUT_MAX, SYNC_MAX_I);
    g_spid_left.setpoint  = g_base_speed;
    g_spid_right.setpoint = g_base_speed;
    g_sync_pid.setpoint   = 0;

    g_enc_left = 0; g_enc_right = 0;
    g_enc_left_prev = 0; g_enc_right_prev = 0;

    /* 初始化时不启动电机，等外部调用 Car_Enable() */
}

void Car_SetSpeed(uint16_t target)
{
    g_base_speed = (float)target;
    PID_Reset(&g_spid_left,  (float)target);
    PID_Reset(&g_spid_right, (float)target);
    PID_Reset(&g_sync_pid,   0);
}

void Car_SetMotorPWM(uint16_t left, uint16_t right)
{
    MotorA_SetPWM(left);
    MotorB_SetPWM(right);
}

float Car_GetSpeedLeft(void)  { return g_speed_left; }
float Car_GetSpeedRight(void) { return g_speed_right; }
uint16_t Car_GetPWMLeft(void)  { return (uint16_t)g_last_left_pwm; }
uint16_t Car_GetPWMRight(void) { return (uint16_t)g_last_right_pwm; }

void Car_SyncPID_Enable(void)  { g_sync_enabled = 1; PID_Reset(&g_sync_pid, 0); }
void Car_SyncPID_Disable(void) { g_sync_enabled = 0; }

void Car_SetManualMode(uint8_t enable) { g_manual_mode = enable; }

void Car_Enable(void)
{
    DL_GPIO_setPins(STBY_PORT, STBY_PINS);
    DL_TimerG_startCounter(PWM_0_INST);
}

void Car_Disable(void)
{
    DL_TimerG_stopCounter(PWM_0_INST);
    DL_GPIO_clearPins(STBY_PORT, STBY_PINS);
}

void Car_Stop(void)
{
    Car_Disable();
    DL_GPIO_clearPins(AIN1_PORT, AIN1_PINS | AIN2_PINS);
    DL_GPIO_clearPins(BIN1_PORT, BIN1_PINS | BIN2_PINS);
}

void Car_Brake(void)
{
    DL_GPIO_setPins(STBY_PORT, STBY_PINS);
    DL_GPIO_setPins(AIN1_PORT, AIN1_PINS | AIN2_PINS);
    DL_GPIO_setPins(BIN1_PORT, BIN1_PINS | BIN2_PINS);
    MotorA_SetPWM(0);
    MotorB_SetPWM(0);
}
