#ifndef GRAY_H_
#define GRAY_H_

#include <stdint.h>

/* 初始化灰度模块的 GPIO（AD0/AD1/AD2 输出 + OUT 输入） */
void Gray_Init(void);

/* 读取 4 路灰度传感器状态，每路 1 bit（0=黑 1=白），bits 0~3 对应 X3~X6 */
uint8_t Gray_ReadLevels(void);

#endif /* GRAY_H_ */