#ifndef TRACK_H_
#define TRACK_H_

#include <stdint.h>

/* 执行一次循迹处理（读取传感器 → 计算误差 → 控制电机） */
void Track_Run(void);

/* 丢线检测 */
uint8_t Track_IsLineLost(void);
void    Track_ClearLost(void);

/* 调试 */
uint8_t Track_GetRawLevels(void);
int16_t Track_GetError(void);

#endif /* TRACK_H_ */
