/*
 * line_follower.c — 灰度传感器循迹实现
 *
 * 使用 ADC0 读取 2~3 路灰度传感器，通过 PID 计算转向量控制小车沿黑线行驶。
 */
#include "ti_msp_dl_config.h"
#include "tuning.h"
#include "line_follower.h"
#include "car_control.h"
#include <ti/devices/msp/msp.h>

/*===========================================================================
 * 灰度传感器引脚
 *   左: PA25 = ADC chan 2,  IOMUX PINCM55
 *   中: PA22 = ADC chan 5,  IOMUX PINCM47
 *   右: PA24 = ADC chan 7,  IOMUX PINCM54
 *===========================================================================*/
#define LF_L_IOMUX     IOMUX_PINCM55
#define LF_L_CHAN      DL_ADC12_INPUT_CHAN_2
#define LF_C_IOMUX     IOMUX_PINCM47
#define LF_C_CHAN      DL_ADC12_INPUT_CHAN_5
#define LF_R_IOMUX     IOMUX_PINCM54
#define LF_R_CHAN      DL_ADC12_INPUT_CHAN_7

/*===========================================================================
 * 循迹 PID 状态
 *===========================================================================*/
typedef struct {
    float Kp, Ki, Kd;
    float integral;
    float prev_error;
    float i_max;
} LF_PID_t;

static LF_PID_t g_lf_pid;
static float    g_lf_error = 0;

/*===========================================================================
 * ADC 单通道读取
 *===========================================================================*/
static uint16_t ADC_ReadChannel(uint32_t chan)
{
    DL_ADC12_configConversionMem(ADC0, DL_ADC12_MEM_IDX_0,
        chan,
        DL_ADC12_REFERENCE_VOLTAGE_VDDA,
        DL_ADC12_SAMPLE_TIMER_SOURCE_SCOMP0,
        DL_ADC12_AVERAGING_MODE_DISABLED,
        DL_ADC12_BURN_OUT_SOURCE_DISABLED,
        DL_ADC12_TRIGGER_MODE_AUTO_NEXT,
        DL_ADC12_WINDOWS_COMP_MODE_DISABLED);

    DL_ADC12_startConversion(ADC0);

    uint32_t timeout = 100000;
    while (DL_ADC12_getStatus(ADC0) & DL_ADC12_STATUS_CONVERSION_ACTIVE) {
        if (--timeout == 0) return 0;
    }

    return DL_ADC12_getMemResult(ADC0, DL_ADC12_MEM_IDX_0);
}

/*===========================================================================
 * LF_Init
 *===========================================================================*/
void LF_Init(void)
{
    /* 传感器引脚 → 模拟功能 */
    DL_GPIO_initPeripheralAnalogFunction(LF_L_IOMUX);
    DL_GPIO_initPeripheralAnalogFunction(LF_C_IOMUX);
    DL_GPIO_initPeripheralAnalogFunction(LF_R_IOMUX);

    /* ADC0 上电 */
    DL_ADC12_reset(ADC0);
    DL_ADC12_enablePower(ADC0);

    DL_ADC12_setPowerDownMode(ADC0, DL_ADC12_POWER_DOWN_MODE_MANUAL);

    /* 时钟: ULPCLK 4MHz / 8 = 500kHz, freq range = 1~4MHz */
    DL_ADC12_ClockConfig clkCfg = {
        .clockSel    = DL_ADC12_CLOCK_ULPCLK,
        .freqRange   = DL_ADC12_CLOCK_FREQ_RANGE_1_TO_4,
        .divideRatio = DL_ADC12_CLOCK_DIVIDE_8
    };
    DL_ADC12_setClockConfig(ADC0, &clkCfg);

    /* 采样时间 125us */
    DL_ADC12_setSampleTime0(ADC0, 125);

    /* 开启 ADC */
    DL_ADC12_enableConversions(ADC0);
    delay_cycles(32000);

    /* 初始化循迹 PID */
    LF_SetPID(LF_KP, LF_KI, LF_KD);
}

/*===========================================================================
 * LF_ReadSensor
 *===========================================================================*/
uint16_t LF_ReadSensor(uint8_t idx)
{
    switch (idx) {
        case LF_SENSOR_LEFT:   return ADC_ReadChannel(LF_L_CHAN);
        case LF_SENSOR_CENTER: return ADC_ReadChannel(LF_C_CHAN);
        case LF_SENSOR_RIGHT:  return ADC_ReadChannel(LF_R_CHAN);
        default: return 0;
    }
}

/*===========================================================================
 * LF_ReadAll
 *===========================================================================*/
void LF_ReadAll(uint16_t raw[LF_SENSOR_COUNT])
{
    raw[0] = LF_ReadSensor(LF_SENSOR_LEFT);
    raw[1] = LF_ReadSensor(LF_SENSOR_CENTER);
    raw[2] = LF_ReadSensor(LF_SENSOR_RIGHT);
}

/*===========================================================================
 * LF_SetPID
 *===========================================================================*/
void LF_SetPID(float kp, float ki, float kd)
{
    g_lf_pid.Kp         = kp;
    g_lf_pid.Ki         = ki;
    g_lf_pid.Kd         = kd;
    g_lf_pid.integral   = 0;
    g_lf_pid.prev_error = 0;
    g_lf_pid.i_max      = LF_I_MAX;
}

/*===========================================================================
 * LF_GetError
 *===========================================================================*/
float LF_GetError(void) { return g_lf_error; }

/*===========================================================================
 * LF_Update — 循迹主函数
 *===========================================================================*/
bool LF_Update(uint16_t base_speed)
{
    uint16_t raw_l = LF_ReadSensor(LF_SENSOR_LEFT);
    uint16_t raw_r = LF_ReadSensor(LF_SENSOR_RIGHT);

    /* 归一化: 0=纯黑, 1=纯白 */
    float nl, nr;
    if (raw_l <= LF_BLACK_THRESHOLD)       nl = 0.0f;
    else if (raw_l >= LF_WHITE_THRESHOLD)  nl = 1.0f;
    else nl = (float)(raw_l - LF_BLACK_THRESHOLD)
            / (float)(LF_WHITE_THRESHOLD - LF_BLACK_THRESHOLD);

    if (raw_r <= LF_BLACK_THRESHOLD)       nr = 0.0f;
    else if (raw_r >= LF_WHITE_THRESHOLD)  nr = 1.0f;
    else nr = (float)(raw_r - LF_BLACK_THRESHOLD)
            / (float)(LF_WHITE_THRESHOLD - LF_BLACK_THRESHOLD);

    /* 丢线检测 */
    if (nl > 0.8f && nr > 0.8f) {
        Car_SetMotorPWM(base_speed / 3, base_speed / 3);
        g_lf_pid.integral   = 0;
        g_lf_pid.prev_error = 0;
        return false;
    }

    /* 误差 = 右 - 左  →  正值偏右需右转, 负值偏左需左转 */
    g_lf_error = nr - nl;

    /* PID */
    float p_out = g_lf_pid.Kp * g_lf_error;
    g_lf_pid.integral += g_lf_error;
    if (g_lf_pid.integral >  g_lf_pid.i_max) g_lf_pid.integral =  g_lf_pid.i_max;
    if (g_lf_pid.integral < -g_lf_pid.i_max) g_lf_pid.integral = -g_lf_pid.i_max;
    float i_out = g_lf_pid.Ki * g_lf_pid.integral;
    float d_out = g_lf_pid.Kd * (g_lf_error - g_lf_pid.prev_error);
    g_lf_pid.prev_error = g_lf_error;

    float steer = p_out + i_out + d_out;
    float max_s = (float)base_speed;
    if (steer >  max_s) steer =  max_s;
    if (steer < -max_s) steer = -max_s;

    int32_t lpwm = (int32_t)base_speed + (int32_t)steer;
    int32_t rpwm = (int32_t)base_speed - (int32_t)steer;

    if (lpwm < 0) lpwm = 0; if (lpwm > 1000) lpwm = 1000;
    if (rpwm < 0) rpwm = 0; if (rpwm > 1000) rpwm = 1000;

    Car_SetMotorPWM((uint16_t)lpwm, (uint16_t)rpwm);
    return true;
}
