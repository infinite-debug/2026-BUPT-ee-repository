/*
 * line_follower.h — 灰度传感器循迹 API
 *
 * 传感器接线:
 *   左灰度 → PA25 (BoosterPack pin 2,  Analog in)
 *   右灰度 → PA24 (BoosterPack pin 27, Analog in)
 *   中灰度 → PA22 (BoosterPack pin 24, Analog in，可选)
 */
#ifndef LINE_FOLLOWER_H
#define LINE_FOLLOWER_H

#include <stdint.h>

/* 灰度传感器数量 */
#define LF_SENSOR_COUNT  3

/* 传感器索引 */
#define LF_SENSOR_LEFT    0
#define LF_SENSOR_CENTER  1
#define LF_SENSOR_RIGHT   2

/* 初始化 ADC 及灰度传感器引脚 */
void LF_Init(void);

/* 读取单个传感器原始值 (0~4095) */
uint16_t LF_ReadSensor(uint8_t idx);

/* 读取所有传感器到数组 raw[LF_SENSOR_COUNT] */
void LF_ReadAll(uint16_t raw[LF_SENSOR_COUNT]);

/*
 * 循迹 PID 控制——每周期调用一次
 *   base_speed: 基础速度 PWM (0~1000)
 *   返回:       true = 检测到线, false = 丢线
 *
 *   内部根据传感器误差计算转向修正，通过 Car_SetMotorPWM 控制电机。
 */
#include <stdbool.h>
bool LF_Update(uint16_t base_speed);

/* 设置循迹 PID 参数 */
void LF_SetPID(float kp, float ki, float kd);

/* 获取当前传感器误差（用于调试） */
float LF_GetError(void);

#endif /* LINE_FOLLOWER_H */
