#include "track.h"
#include "gray.h"
#include "car_control.h"
#include "tuning.h"

/*
 * 黑线对应的 OUT 电平（0 = 黑线有效）。
 */
#define GRAY_LINE_LEVEL         (1U)   /* LM393 比较器：HIGH=检测到黑线 */

/*
 * error 在 -1～+1 时按直行处理。
 */
#define TRACK_STRAIGHT_RANGE    (1)

/*
 * 转向时慢侧的减速系数（慢侧 = 快侧 / SLOW_DIVISOR）。
 */
#define SLOW_DIVISOR            3

/*
 * 四路传感器权重（X3=-3, X4=-1, X5=1, X6=3）。
 */
static const int8_t g_grayWeight[4] = { -3, -1, 1, 3 };

/* ---- 状态 ---- */
static volatile uint8_t  g_rawLevels   = 0U;
static volatile uint8_t  g_activeCount = 0U;
static volatile int16_t  g_trackError  = 0;

/* ---- 丢线标志 ---- */
static volatile uint8_t  g_lineLost    = 0U;

/*===========================================================================
 * Track_CalculateError
 *===========================================================================*/
static int16_t Track_CalculateError(uint8_t rawLevels)
{
    int16_t weightSum = 0;
    uint8_t count = 0U;
    uint8_t i;

    for (i = 0U; i < 4U; i++) {
        uint8_t level = (uint8_t)((rawLevels >> i) & 0x01U);
        if (level == GRAY_LINE_LEVEL) {
            weightSum += g_grayWeight[i];
            count++;
        }
    }
    g_activeCount = count;

    if (count == 0U) return 0;
    return (int16_t)(weightSum / (int16_t)count);
}

/*===========================================================================
 * 运动控制
 *===========================================================================*/
static void Track_GoStraight(void)
{
    Car_SetMotorPWM(TRACK_SPEED, TRACK_SPEED);
}

static void Track_TurnLeft(void)
{
    /* 左转: 左轮减速, 右轮全速 */
    Car_SetMotorPWM(TRACK_SPEED / SLOW_DIVISOR, TRACK_SPEED);
}

static void Track_TurnRight(void)
{
    /* 右转: 左轮全速, 右轮减速 */
    Car_SetMotorPWM(TRACK_SPEED, TRACK_SPEED / SLOW_DIVISOR);
}

static void Track_LineLost(void)
{
    g_lineLost = 1U;
    Car_SetMotorPWM(0, 0);   /* 丢线即停 */
}

/*===========================================================================
 * Track_Run
 *===========================================================================*/
void Track_Run(void)
{
    g_rawLevels  = Gray_ReadLevels();
    g_trackError = Track_CalculateError(g_rawLevels);

    if (g_activeCount == 0U) {
        Track_LineLost();
    } else if (g_trackError < -TRACK_STRAIGHT_RANGE) {
        Track_TurnLeft();
    } else if (g_trackError > TRACK_STRAIGHT_RANGE) {
        Track_TurnRight();
    } else {
        Track_GoStraight();
    }
}

/*===========================================================================
 * 公开接口
 *===========================================================================*/
uint8_t Track_GetRawLevels(void) { return g_rawLevels; }
int16_t Track_GetError(void)     { return g_trackError; }
uint8_t Track_IsLineLost(void)   { return g_lineLost; }
void    Track_ClearLost(void)    { g_lineLost = 0U; }
