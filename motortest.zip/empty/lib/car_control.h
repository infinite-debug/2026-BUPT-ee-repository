/*
 * car_control.h — 小车运动控制 API
 */
#ifndef CAR_CONTROL_H
#define CAR_CONTROL_H

#include <stdint.h>

/* 初始化（编码器 + SysTick + PID），调用后电机处于关闭状态 */
void Car_Init(void);

/* 使能 / 关闭电机驱动（STBY + PWM） */
void Car_Enable(void);
void Car_Disable(void);

/* 设置速度目标（编码器脉冲数/控制周期） */
void Car_SetSpeed(uint16_t target);

/* 获取当前左右轮速（count/周期） */
float Car_GetSpeedLeft(void);
float Car_GetSpeedRight(void);

/* 获取当前左右轮 PWM 输出 */
uint16_t Car_GetPWMLeft(void);
uint16_t Car_GetPWMRight(void);

/* 紧急停车 / 刹车 */
void Car_Stop(void);
void Car_Brake(void);

/* 同步 PID 开关（调试时关闭，走直线时打开） */
void Car_SyncPID_Enable(void);
void Car_SyncPID_Disable(void);

/* 手动 PWM 模式（循迹用）：启用后速度 PID 停写 PWM，由外部直接控制 */
void Car_SetMotorPWM(uint16_t left, uint16_t right);
void Car_SetManualMode(uint8_t enable);

#endif /* CAR_CONTROL_H */
