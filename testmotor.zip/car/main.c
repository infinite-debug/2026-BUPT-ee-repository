/**
 * main.c — 开环直行测试：两轮等速前进 2 秒，停 2 秒，循环
 */

#include "ti_msp_dl_config.h"
#include "app/uart_protocol.h"
#include "lib/motor.h"
#include "lib/oled.h"

UARTProtocol_t g_uart_proto;

static void delay_ms(uint32_t ms)
{
    for (volatile uint32_t i = 0; i < ms * 3200; i++) { }
}

int main(void)
{
    SYSCFG_DL_init();

    Motor_Init();       /* PWM + 方向引脚初始化 */
    OLED_Init();
    OLED_CLS();
    OLED_ShowString(0, 0, "GO STRAIGHT", 16);

    while (1) {
        /* 前进 2 秒 */
        OLED_ShowString(2, 0, "FWD   ", 16);
        Motor_Left(4000);       /* 左轮 40% 占空比 */
        Motor_Right(4000);      /* 右轮 40% 占空比 */
        delay_ms(2000);

        /* 停 2 秒 */
        OLED_ShowString(2, 0, "STOP  ", 16);
        Motor_Stop();
        delay_ms(2000);
    }
}
