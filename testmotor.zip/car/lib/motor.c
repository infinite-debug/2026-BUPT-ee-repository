/**
 * motor.c — TB6612 IN1+IN2+PWM 三线模式
 *
 * 正转: IN1=1, IN2=0 + PWM
 * 反转: IN1=0, IN2=1 + PWM
 * 刹车: IN1=1, IN2=1
 * 滑行: IN1=0, IN2=0
 */

#include "motor.h"
#include "config.h"

void Motor_Init(void)
{
    DL_TimerG_enablePower(MOTOR_INST);

    DL_TimerG_ClockConfig clk = { DL_TIMER_CLOCK_BUSCLK, DL_TIMER_CLOCK_DIVIDE_1 };
    DL_TimerG_setClockConfig(MOTOR_INST, &clk);

    DL_Timer_PWMConfig pwm = { PWM_PERIOD, DL_TIMER_PWM_MODE_EDGE_ALIGN, false, DL_TIMER_START };
    DL_TimerG_initPWMMode(MOTOR_INST, &pwm);

    DL_TimerG_setCaptureCompareValue(MOTOR_INST, 0, GPIO_MOTOR_C0_IDX);
    DL_Timer_setCaptureCompareOutCtl(MOTOR_INST, 0,
        DL_TIMER_CC_OCTL_INV_OUT_DISABLED, DL_TIMER_CC_OCTL_SRC_FUNCVAL, GPIO_MOTOR_C0_IDX);

    DL_TimerG_setCaptureCompareValue(MOTOR_INST, 0, GPIO_MOTOR_C1_IDX);
    DL_Timer_setCaptureCompareOutCtl(MOTOR_INST, 0,
        DL_TIMER_CC_OCTL_INV_OUT_DISABLED, DL_TIMER_CC_OCTL_SRC_FUNCVAL, GPIO_MOTOR_C1_IDX);

    /* 滑行: IN1=0, IN2=0 */
    DL_GPIO_clearPins(MOTOR_DIR_PORT,
        MOTOR_DIR_L_IN1_PIN | MOTOR_DIR_L_IN2_PIN |
        MOTOR_DIR_R_IN1_PIN | MOTOR_DIR_R_IN2_PIN);
}

static void tb6612_set(uint32_t in1, uint32_t in2, uint32_t val)
{
    if (val & 1) DL_GPIO_setPins(MOTOR_DIR_PORT, in1);
    else         DL_GPIO_clearPins(MOTOR_DIR_PORT, in1);
    if (val & 2) DL_GPIO_setPins(MOTOR_DIR_PORT, in2);
    else         DL_GPIO_clearPins(MOTOR_DIR_PORT, in2);
}

void Motor_Left(int16_t duty)
{
    if (duty > 0) {
        tb6612_set(MOTOR_DIR_L_IN1_PIN, MOTOR_DIR_L_IN2_PIN, 1); /* IN1=1,IN2=0 */
        DL_TimerG_setCaptureCompareValue(MOTOR_INST, (uint32_t)duty, GPIO_MOTOR_C0_IDX);
    } else if (duty < 0) {
        tb6612_set(MOTOR_DIR_L_IN1_PIN, MOTOR_DIR_L_IN2_PIN, 2); /* IN1=0,IN2=1 */
        DL_TimerG_setCaptureCompareValue(MOTOR_INST, (uint32_t)(-duty), GPIO_MOTOR_C0_IDX);
    } else {
        tb6612_set(MOTOR_DIR_L_IN1_PIN, MOTOR_DIR_L_IN2_PIN, 3); /* IN1=1,IN2=1 刹车 */
        DL_TimerG_setCaptureCompareValue(MOTOR_INST, 0, GPIO_MOTOR_C0_IDX);
    }
}

void Motor_Right(int16_t duty)
{
    if (duty > 0) {
        tb6612_set(MOTOR_DIR_R_IN1_PIN, MOTOR_DIR_R_IN2_PIN, 1);
        DL_TimerG_setCaptureCompareValue(MOTOR_INST, (uint32_t)duty, GPIO_MOTOR_C1_IDX);
    } else if (duty < 0) {
        tb6612_set(MOTOR_DIR_R_IN1_PIN, MOTOR_DIR_R_IN2_PIN, 2);
        DL_TimerG_setCaptureCompareValue(MOTOR_INST, (uint32_t)(-duty), GPIO_MOTOR_C1_IDX);
    } else {
        tb6612_set(MOTOR_DIR_R_IN1_PIN, MOTOR_DIR_R_IN2_PIN, 3);
        DL_TimerG_setCaptureCompareValue(MOTOR_INST, 0, GPIO_MOTOR_C1_IDX);
    }
}

void Motor_Stop(void) { Motor_Left(0); Motor_Right(0); }
