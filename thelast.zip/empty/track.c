#include "track.h"

#include <stdint.h>

#include "car_config.h"
#include "grey.h"
#include "motor.h"

/* 调试开关：置 1 绕过 PD，有黑线就直行；置 0 恢复正常循迹 */
#define DEBUG_SIMPLE_TRACK 0

static int16_t g_previous_error;

volatile uint8_t g_track_pattern;
volatile int16_t g_track_left_speed;
volatile int16_t g_track_right_speed;
volatile TrackState g_track_state;
volatile int16_t g_track_base_speed = TRACK_BASE_SPEED;
volatile uint8_t g_brake_active;
volatile uint8_t g_finish_enabled;
volatile uint16_t g_finish_delay;

static int16_t clamp_forward_speed(int32_t speed)
{
    if (speed < TRACK_MIN_SPEED) return TRACK_MIN_SPEED;
    if (speed > TRACK_MAX_SPEED) return TRACK_MAX_SPEED;
    return (int16_t)speed;
}

static void stop_car(TrackState state)
{
    motor_stop();
    g_previous_error = 0;
    g_track_left_speed = 0;
    g_track_right_speed = 0;
    g_track_state = state;
}

static bool is_one_contiguous_black_area(uint8_t pattern)
{
    while (((pattern & 0x01U) == 0U) && (pattern != 0U))
        pattern >>= 1U;
    while ((pattern & 0x01U) != 0U)
        pattern >>= 1U;
    return pattern == 0U;
}

TrackCommand track_calculate_command(uint8_t pattern, int16_t previous_error)
{
    static const int16_t weights[SENSOR_COUNT] = TRACK_WEIGHTS_INIT;
    TrackCommand command = {0, 0, 0, TRACK_STATE_INVALID_PATTERN, false};
    int32_t weighted_sum = 0, correction;
    uint8_t count = 0U, i;

    g_track_pattern = pattern & TRACK_SENSOR_MASK;
    pattern &= TRACK_SENSOR_MASK;

#if DEBUG_SIMPLE_TRACK
    if (pattern != 0x00U) {
        command.left_speed  = (int16_t)((int32_t)g_track_base_speed * TRACK_BALANCE_L);
        command.right_speed = (int16_t)((int32_t)g_track_base_speed * TRACK_BALANCE_R);
        command.error = 0;
        command.state = TRACK_STATE_VALID_LINE;
        command.line_found = true;
    } else {
        command.state = TRACK_STATE_WHITE_LOST;
    }
    return command;
#endif

    if (pattern == 0x00U) {
        command.state = TRACK_STATE_WHITE_LOST;
        /* 继续沿用上一拍的 error，不归零，弯道丢线时保持转向 */
        command.error = previous_error;
        correction = (int32_t)TRACK_KP * command.error +
                     (int32_t)TRACK_KD * (command.error - previous_error);
        command.left_speed  = clamp_forward_speed(
            (int32_t)(((int32_t)g_track_base_speed + correction) * TRACK_BALANCE_L));
        command.right_speed = clamp_forward_speed(
            (int32_t)(((int32_t)g_track_base_speed - correction) * TRACK_BALANCE_R));
        command.state = TRACK_STATE_WHITE_LOST;
        command.line_found = true; /* 继续行驶，不刹车 */
        return command;
    }

    {
        uint8_t j, bits = 0;
        for (j = 0; j < SENSOR_COUNT; j++)
            if (pattern & (1U << j)) bits++;
        if (bits >= FINISH_MIN_BITS) {
            command.state = TRACK_STATE_FINISH;
            return command;
        }
    }

    if (!is_one_contiguous_black_area(pattern)) {
        command.state = TRACK_STATE_INVALID_PATTERN;
        return command;
    }

    if (pattern == TRACK_CENTER_PATTERN) {
        command.left_speed  = (int16_t)((int32_t)g_track_base_speed * TRACK_BALANCE_L);
        command.right_speed = (int16_t)((int32_t)g_track_base_speed * TRACK_BALANCE_R);
        command.error = 0;
        command.state = TRACK_STATE_VALID_LINE;
        command.line_found = true;
        return command;
    }

    for (i = 0; i < SENSOR_COUNT; i++) {
        if ((pattern & (uint8_t)(1U << i)) != 0U) {
            weighted_sum += weights[i];
            count++;
        }
    }

    if (weighted_sum == 0) {
        command.state = TRACK_STATE_INVALID_PATTERN;
        return command;
    }

    command.error = (int16_t)(weighted_sum / count);
    correction = (int32_t)TRACK_KP * command.error +
                 (int32_t)TRACK_KD * (command.error - previous_error);

    command.left_speed  = clamp_forward_speed(
        (int32_t)(((int32_t)g_track_base_speed + correction) * TRACK_BALANCE_L));
    command.right_speed = clamp_forward_speed(
        (int32_t)(((int32_t)g_track_base_speed - correction) * TRACK_BALANCE_R));
    command.state = TRACK_STATE_VALID_LINE;
    command.line_found = true;

    return command;
}

void track_set_speed(int16_t speed)
{
    g_track_base_speed = speed;
}

void track_init(void)
{
    g_previous_error = 0;
    g_track_base_speed = TRACK_BASE_SPEED;
    g_track_pattern = 0U;
    g_track_left_speed = 0;
    g_track_right_speed = 0;
    g_track_state = TRACK_STATE_WHITE_LOST;
    g_brake_active = 0;
    g_finish_enabled = 0;
    g_finish_delay = 0;
    motor_stop();
}

void track_update(void)
{
    uint8_t pattern = grey_read_5ch();
    TrackCommand command = track_calculate_command(pattern, g_previous_error);

    g_track_pattern = pattern;

    /* 终点处理：刹车停车 */
    if (command.state == TRACK_STATE_FINISH) {
        if (g_finish_enabled) {
            g_finish_delay = 200;
            g_finish_enabled = 0;
            g_track_state = TRACK_STATE_FINISH;
            return;
        }
        if (g_finish_delay > 0) {
            g_track_state = TRACK_STATE_FINISH;
            return;
        }
        stop_car(TRACK_STATE_FINISH);
        return;
    }

    /* 无效模式：保持最后速度继续行驶，不刹车 */
    if (command.state == TRACK_STATE_INVALID_PATTERN) {
        g_track_state = command.state;
        return;
    }

    g_track_left_speed = command.left_speed;
    g_track_right_speed = command.right_speed;
    g_track_state = command.state;
    motor_set_speeds(command.left_speed, command.right_speed);
    g_previous_error = command.error;
}
