#include "grey.h"

#include <stdint.h>

#include "car_config.h"

volatile uint8_t g_grey_raw_pattern;
volatile uint8_t g_grey_line_pattern;

void grey_init(void)
{
    /* PB6/PB7/PB8: syscfg 配成了 output，重配为 input */
    DL_GPIO_initDigitalInputFeatures(IOMUX_PINCM23, DL_GPIO_INVERSION_DISABLE,
        DL_GPIO_RESISTOR_NONE, DL_GPIO_HYSTERESIS_DISABLE,
        DL_GPIO_WAKEUP_DISABLE);
    DL_GPIO_initDigitalInputFeatures(IOMUX_PINCM24, DL_GPIO_INVERSION_DISABLE,
        DL_GPIO_RESISTOR_NONE, DL_GPIO_HYSTERESIS_DISABLE,
        DL_GPIO_WAKEUP_DISABLE);
    DL_GPIO_initDigitalInputFeatures(IOMUX_PINCM25, DL_GPIO_INVERSION_DISABLE,
        DL_GPIO_RESISTOR_NONE, DL_GPIO_HYSTERESIS_DISABLE,
        DL_GPIO_WAKEUP_DISABLE);
    DL_GPIO_disableOutput(GPIOB,
        DL_GPIO_PIN_6 | DL_GPIO_PIN_7 | DL_GPIO_PIN_8);

    /* PA25 由 syscfg 配置为 input；PA8 手动配为 input */
    DL_GPIO_initDigitalInputFeatures(IOMUX_PINCM19, DL_GPIO_INVERSION_DISABLE,
        DL_GPIO_RESISTOR_NONE, DL_GPIO_HYSTERESIS_DISABLE,
        DL_GPIO_WAKEUP_DISABLE);
    DL_GPIO_disableOutput(GPIOA, DL_GPIO_PIN_8);

    g_grey_raw_pattern = 0U;
}

uint8_t grey_read_5ch(void)
{
    uint8_t pattern = 0U;

    if (DL_GPIO_readPins(GREY_X1_PORT, GREY_X1_PIN) == 0U) pattern |= 0x01U;
    if (DL_GPIO_readPins(GREY_X2_PORT, GREY_X2_PIN) == 0U) pattern |= 0x02U;
    if (DL_GPIO_readPins(GREY_X3_PORT, GREY_X3_PIN) == 0U) pattern |= 0x04U;
    if (DL_GPIO_readPins(GREY_X4_PORT, GREY_X4_PIN) == 0U) pattern |= 0x08U;
    if (DL_GPIO_readPins(GREY_X5_PORT, GREY_X5_PIN) == 0U) pattern |= 0x10U;

    g_grey_raw_pattern = pattern;

    return pattern;
}
