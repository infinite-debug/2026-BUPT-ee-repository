#include "motor.h"

#include <stdbool.h>
#include <stdint.h>

#include "car_config.h"

static int16_t clamp_signed_speed(int32_t speed)
{
    if (speed > MOTOR_SPEED_MAX) {
        return MOTOR_SPEED_MAX;
    }
    if (speed < -MOTOR_SPEED_MAX) {
        return -MOTOR_SPEED_MAX;
    }
    return (int16_t) speed;
}

static void set_pwm(uint16_t speed, GPTIMER_Regs *timer,
                    DL_TIMER_CC_INDEX cc_index)
{
    uint32_t load;
    uint32_t compare;

    if (speed > MOTOR_SPEED_MAX) {
        speed = MOTOR_SPEED_MAX;
    }

    load = DL_TimerG_getLoadValue(timer);
    compare = (uint32_t) (((uint64_t) load *
                          (uint32_t) (MOTOR_SPEED_MAX - speed)) /
                         MOTOR_SPEED_MAX);

    DL_TimerG_setCaptureCompareValue(timer, compare, cc_index);
}

static uint16_t set_one_motor(uint32_t in1_pin,
                              uint32_t in2_pin,
                              int16_t requested_speed,
                              uint8_t reversed)
{
    int32_t speed = clamp_signed_speed(requested_speed);
    bool backward;

    if (speed == 0) {
        DL_GPIO_clearPins(MOTOR_GPIO_PORT, in1_pin | in2_pin);
        return 0U;
    }

    backward = (speed < 0);
    if (backward) {
        speed = -speed;
    }

    if (reversed != 0U) {
        backward = !backward;
    }

    if (backward) {
        DL_GPIO_clearPins(MOTOR_GPIO_PORT, in1_pin);
        DL_GPIO_setPins(MOTOR_GPIO_PORT, in2_pin);
    } else {
        DL_GPIO_setPins(MOTOR_GPIO_PORT, in1_pin);
        DL_GPIO_clearPins(MOTOR_GPIO_PORT, in2_pin);
    }

    return (uint16_t) speed;
}

void motor_stop(void)
{
    set_pwm(0U, MOTOR_LEFT_PWM_INST, MOTOR_LEFT_PWM_CC);
    set_pwm(0U, MOTOR_RIGHT_PWM_INST, MOTOR_RIGHT_PWM_CC);

    DL_GPIO_clearPins(MOTOR_GPIO_PORT,
        MOTOR_AIN1_PIN | MOTOR_AIN2_PIN |
        MOTOR_BIN1_PIN | MOTOR_BIN2_PIN |
        MOTOR_STBY_PIN);
}

void motor_brake(void)
{
    motor_set_speeds(-BRAKE_PWM, -BRAKE_PWM);
}

void motor_short_brake(void)
{
    set_pwm(MOTOR_SPEED_MAX, MOTOR_LEFT_PWM_INST, MOTOR_LEFT_PWM_CC);
    set_pwm(MOTOR_SPEED_MAX, MOTOR_RIGHT_PWM_INST, MOTOR_RIGHT_PWM_CC);
    DL_GPIO_setPins(MOTOR_GPIO_PORT,
        MOTOR_AIN1_PIN | MOTOR_AIN2_PIN |
        MOTOR_BIN1_PIN | MOTOR_BIN2_PIN);
    DL_GPIO_setPins(MOTOR_GPIO_PORT, MOTOR_STBY_PIN);
}

void motor_init(void)
{
    DL_TimerG_ClockConfig clk_cfg = {
        .clockSel = DL_TIMER_CLOCK_BUSCLK,
        .divideRatio = DL_TIMER_CLOCK_DIVIDE_1,
        .prescale = 0U
    };
    DL_TimerG_PWMConfig pwm_cfg = {
        .pwmMode = DL_TIMER_PWM_MODE_EDGE_ALIGN,
        .period = 1600,
        .isTimerWithFourCC = false,
        .startTimer = DL_TIMER_STOP
    };

    /* PB9(BIN1), PB19(BIN2): not in syscfg, manual output */
    DL_GPIO_initDigitalOutput(IOMUX_PINCM26);
    DL_GPIO_initDigitalOutput(IOMUX_PINCM45);
    DL_GPIO_clearPins(MOTOR_GPIO_PORT, MOTOR_BIN1_PIN | MOTOR_BIN2_PIN);
    DL_GPIO_enableOutput(MOTOR_GPIO_PORT, MOTOR_BIN1_PIN | MOTOR_BIN2_PIN);

    /* PB3 → TIMG6 CCP1 → left motor PWMA */
    DL_TimerG_reset(MOTOR_LEFT_PWM_INST);
    DL_TimerG_enablePower(MOTOR_LEFT_PWM_INST);
    delay_cycles(16);

    DL_GPIO_initPeripheralOutputFunction(
        IOMUX_PINCM16, IOMUX_PINCM16_PF_TIMG6_CCP1);
    DL_GPIO_enableOutput(GPIOB, DL_GPIO_PIN_3);

    DL_TimerG_setClockConfig(MOTOR_LEFT_PWM_INST, &clk_cfg);
    DL_TimerG_initPWMMode(MOTOR_LEFT_PWM_INST, &pwm_cfg);
    DL_TimerG_setCounterControl(MOTOR_LEFT_PWM_INST,
        DL_TIMER_CZC_CCCTL0_ZCOND,
        DL_TIMER_CAC_CCCTL0_ACOND,
        DL_TIMER_CLC_CCCTL0_LCOND);
    DL_TimerG_setCaptureCompareOutCtl(MOTOR_LEFT_PWM_INST,
        DL_TIMER_CC_OCTL_INIT_VAL_LOW,
        DL_TIMER_CC_OCTL_INV_OUT_DISABLED,
        DL_TIMER_CC_OCTL_SRC_FUNCVAL,
        DL_TIMERG_CAPTURE_COMPARE_1_INDEX);
    DL_TimerG_setCaptCompUpdateMethod(MOTOR_LEFT_PWM_INST,
        DL_TIMER_CC_UPDATE_METHOD_IMMEDIATE,
        DL_TIMERG_CAPTURE_COMPARE_1_INDEX);
    DL_TimerG_setCaptureCompareValue(MOTOR_LEFT_PWM_INST,
        1600, DL_TIMER_CC_1_INDEX);
    DL_TimerG_enableClock(MOTOR_LEFT_PWM_INST);
    DL_TimerG_setCCPDirection(MOTOR_LEFT_PWM_INST, DL_TIMER_CC1_OUTPUT);

    motor_stop();
    DL_TimerG_startCounter(MOTOR_LEFT_PWM_INST);
    DL_TimerG_startCounter(MOTOR_RIGHT_PWM_INST);
}

void motor_set_speeds(int16_t left_speed, int16_t right_speed)
{
    uint16_t left_pwm;
    uint16_t right_pwm;

    left_speed = clamp_signed_speed(left_speed);
    right_speed = clamp_signed_speed(right_speed);

    if ((left_speed == 0) && (right_speed == 0)) {
        motor_stop();
        return;
    }

    left_pwm = set_one_motor(
        MOTOR_AIN1_PIN, MOTOR_AIN2_PIN,
        left_speed, LEFT_MOTOR_REVERSED);
    right_pwm = set_one_motor(
        MOTOR_BIN1_PIN, MOTOR_BIN2_PIN,
        right_speed, RIGHT_MOTOR_REVERSED);

    set_pwm(left_pwm, MOTOR_LEFT_PWM_INST, MOTOR_LEFT_PWM_CC);
    set_pwm(right_pwm, MOTOR_RIGHT_PWM_INST, MOTOR_RIGHT_PWM_CC);
    DL_GPIO_setPins(MOTOR_GPIO_PORT, MOTOR_STBY_PIN);
}
