#ifndef GREY_H_
#define GREY_H_

#include <stdint.h>

extern volatile uint8_t g_grey_raw_pattern;

void grey_init(void);
uint8_t grey_read_5ch(void);

#endif
