#ifndef CAR_CONFIG_H_
#define CAR_CONFIG_H_

#include "ti_msp_dl_config.h"

/*
 * MSPM0G3507 + TB6612 + 5-channel IR sensor
 * Sensors X1-X5 read directly via GPIO.
 *
 * PWM (dual timer, TIMG12 CCP0 on PA10 was damaged):
 *   PB3 -> TIMG6 CCP1 -> TB6612 PWMA (left motor)
 *   PA31 -> TIMG12 CCP1 -> TB6612 PWMB (right motor)
 *
 * TB6612 (PB0 damaged, AIN1 moved to PB2):
 *   PB2 -> AIN1, PB1 -> AIN2
 *   PB9 -> BIN1, PB19 -> BIN2
 *   PB4 -> STBY
 */

/* ============================================================
 *  硬件引脚定义
 * ============================================================ */
#define MOTOR_LEFT_PWM_INST            TIMG6
#define MOTOR_RIGHT_PWM_INST           TIMG12
#define MOTOR_LEFT_PWM_CC              DL_TIMER_CC_1_INDEX
#define MOTOR_RIGHT_PWM_CC             DL_TIMER_CC_1_INDEX

#define MOTOR_GPIO_PORT                GPIOB
#define MOTOR_AIN1_PIN                 DL_GPIO_PIN_2   /* was PB0, damaged */
#define MOTOR_AIN2_PIN                 DL_GPIO_PIN_1
#define MOTOR_BIN1_PIN                 DL_GPIO_PIN_9
#define MOTOR_BIN2_PIN                 DL_GPIO_PIN_19
#define MOTOR_STBY_PIN                 DL_GPIO_PIN_4

/* ============================================================
 *  红外传感器 (5路直读 GPIO)
 * ============================================================ */
/* 5路传感器引脚: X1-X5 从左到右 */
#define GREY_X1_PORT                   GPIOB
#define GREY_X1_PIN                    DL_GPIO_PIN_6   /* PB6 */
#define GREY_X2_PORT                   GPIOB
#define GREY_X2_PIN                    DL_GPIO_PIN_7   /* PB7 */
#define GREY_X3_PORT                   GPIOB
#define GREY_X3_PIN                    DL_GPIO_PIN_8   /* PB8 */
#define GREY_X4_PORT                   GPIOA
#define GREY_X4_PIN                    DL_GPIO_PIN_25  /* PA25 */
#define GREY_X5_PORT                   GPIOA
#define GREY_X5_PIN                    DL_GPIO_PIN_8   /* PA8 */

#define SENSOR_COUNT                    5
#define TRACK_SENSOR_MASK              0x1FU
#define TRACK_CENTER_PATTERN           0x04U
#define FINISH_MIN_BITS                4

/* ============================================================
 *  循迹 PD 控制器
 * ============================================================ */
/* 基础速度 (0~1000 PWM)，越大越快 */
#define TRACK_BASE_SPEED               250

/* 最高速度（转弯时外侧轮可达此速度） */
#define TRACK_MAX_SPEED                650

/* 最低速度（防止堵转），低于 25% 占空比电机带载无法启动 */
#define TRACK_MIN_SPEED                150

/* P 增益：error × KP = 速度修正量 */
#define TRACK_KP                       120

/* D 增益：(error - prev_error) × KD = 阻尼/预判 */
#define TRACK_KD                       24

/* 左右轮平衡：右轮偏快 → < 1.0，左轮偏快 → > 1.0 */
#define TRACK_BALANCE_L                1.00f
#define TRACK_BALANCE_R                1.00f

/*
 * 传感器位置权重 (5路红外, 等间距居中)
 * X1=-4, X2=-2, X3=0, X4=+2, X5=+4
 */
#define TRACK_WEIGHTS_INIT             {8, 4, 0, -4, -8}

/* ============================================================
 *  电机
 * ============================================================ */
/* 急刹车反向 PWM */
#define BRAKE_PWM                      800
#define BRAKE_DURATION_MS              200

/* PWM 满量程 */
#define MOTOR_SPEED_MAX                1000

/* 电机方向反转 (0=正常, 1=反转) */
#define LEFT_MOTOR_REVERSED            0U
#define RIGHT_MOTOR_REVERSED           0U

/* ============================================================
 *  主循环
 * ============================================================ */
/* 主循环延时 (cycles @ 32MHz), 32000 ≈ 1ms */
#define TRACK_LOOP_DELAY_CYCLES        32000U

/* ============================================================
 *  按钮 (S1)
 * ============================================================ */
#define BUTTON_GPIO_PORT               GPIOA
#define BUTTON_GPIO_PIN                DL_GPIO_PIN_18
#define BUTTON_PINCM                   IOMUX_PINCM40
/* 按下为低电平，上拉 */

#endif /* CAR_CONFIG_H_ */
