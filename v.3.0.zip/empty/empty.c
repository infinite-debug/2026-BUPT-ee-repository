/*
 * 循迹小车 — 按 S1 启动，丢线 / 再按 S1 停车
 */
#include "ti_msp_dl_config.h"

#include "car_config.h"
#include "grey.h"
#include "motor.h"
#include "track.h"

static void btn_init(void)
{
    DL_GPIO_initDigitalInputFeatures(
        BUTTON_PINCM,
        DL_GPIO_INVERSION_DISABLE,
        DL_GPIO_RESISTOR_PULL_UP,
        DL_GPIO_HYSTERESIS_ENABLE,
        DL_GPIO_WAKEUP_DISABLE);
}

static uint8_t btn_pressed(void)
{
    return DL_GPIO_readPins(BUTTON_GPIO_PORT, BUTTON_GPIO_PIN) == 0U;
}

static void btn_wait_press(void)
{
    while (!btn_pressed()) { }
    delay_cycles(320000);
    while (btn_pressed()) { }
    delay_cycles(320000);
}

int main(void)
{
    SYSCFG_DL_init();

    grey_init();
    motor_init();
    track_init();
    btn_init();

    uint8_t running = 0;
    uint16_t lost_count = 0;
    uint16_t tick = 0;
    uint16_t brake_count = 0;

    while (1) {
        if (!running) {
            motor_stop();
            lost_count = 0;
            tick = 0;
            brake_count = 0;
            g_finish_enabled = 0;
            g_finish_delay = 0;
            btn_wait_press();
            track_init();
            running = 1;
        }

        if (g_brake_active) {
            brake_count--;
            if (brake_count == 0) {
                motor_stop();
                running = 0;
            }
            delay_cycles(TRACK_LOOP_DELAY_CYCLES);
            continue;
        }

        track_update();
        delay_cycles(TRACK_LOOP_DELAY_CYCLES);

        if (g_brake_active) {
            brake_count = BRAKE_DURATION_MS;
            continue;
        }

        if (g_finish_delay > 0) {
            g_finish_delay--;
            if (g_finish_delay == 0) {
                motor_short_brake();
                g_brake_active = 1;
                continue;
            }
        }

        tick++;

        if (tick > 10000) {
            g_finish_enabled = 1;
        }

        if (g_track_state != TRACK_STATE_VALID_LINE &&
            g_track_state != TRACK_STATE_FINISH) {
            lost_count++;
            if (lost_count >= 200) {
                running = 0;
            }
        } else {
            lost_count = 0;
        }

        if (btn_pressed()) {
            motor_stop();
            while (btn_pressed()) { }
            delay_cycles(320000);
            running = 0;
        }
    }
}
