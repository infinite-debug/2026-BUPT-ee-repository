#ifndef CAR_CONFIG_H_
#define CAR_CONFIG_H_

#include "ti_msp_dl_config.h"

/*
 * MSPM0G3507 + TB6612 + eight-channel grayscale board
 * Software uses only the middle six probes: X2...X7.
 *
 * PWM:
 *   PB13 -> TIMG12 CCP0 -> TB6612 PWMA (left motor)
 *   PA31 -> TIMG12 CCP1 -> TB6612 PWMB (right motor)
 *
 * TB6612:
 *   PB0 -> AIN1, PB1 -> AIN2
 *   PB9 -> BIN1, PB19 -> BIN2
 *   PB4 -> STBY
 *
 * CD4051 grayscale board:
 *   PB6 -> AD0, PB7 -> AD1, PB8 -> AD2
 *   PA25 <- OUT
 */

/* ============================================================
 *  硬件引脚定义
 * ============================================================ */
#define MOTOR_PWM_INST                 PWM_0_INST
#define MOTOR_LEFT_PWM_CC              DL_TIMER_CC_0_INDEX
#define MOTOR_RIGHT_PWM_CC             DL_TIMER_CC_1_INDEX

#define MOTOR_GPIO_PORT                GPIOB
#define MOTOR_AIN1_PIN                 DL_GPIO_PIN_0
#define MOTOR_AIN2_PIN                 DL_GPIO_PIN_1
#define MOTOR_BIN1_PIN                 DL_GPIO_PIN_9
#define MOTOR_BIN2_PIN                 DL_GPIO_PIN_19
#define MOTOR_STBY_PIN                 DL_GPIO_PIN_4

#define GREY_SELECT_PORT               GPIOB
#define GREY_AD0_PIN                   DL_GPIO_PIN_6
#define GREY_AD1_PIN                   DL_GPIO_PIN_7
#define GREY_AD2_PIN                   DL_GPIO_PIN_8

#define GREY_OUT_PORT                  GPIOA
#define GREY_OUT_PIN                   DL_GPIO_PIN_25

/* ============================================================
 *  灰度传感器
 * ============================================================ */
/* PA25 raw level when probe sees white cloth: 0=LOW, 1=HIGH */
#define GREY_WHITE_LEVEL               0U

/* CD4051 settling delay (cycles @ 32MHz) */
#define GREY_SETTLE_DELAY_CYCLES       200U

/* Sensor channel range on CD4051: X2(1) ... X7(6) */
#define GREY_CHANNEL_FIRST             1U
#define GREY_CHANNEL_LAST              6U

/* X1...X8 map to bits 0...7. X1/X8 disabled. Active: X2...X7 = bits 1...6 */
#define TRACK_SENSOR_MASK              0x7EU
#define TRACK_CENTER_PATTERN           0x18U
#define TRACK_ALL_DARK_PATTERN         0x7EU

/* ============================================================
 *  循迹 PD 控制器
 * ============================================================ */
/* 基础速度 (0~1000 PWM)，越大越快 */
#define TRACK_BASE_SPEED               440

/* 10秒后降到的慢速 */
#define TRACK_SLOW_SPEED               250

/* 最高速度 */
#define TRACK_MAX_SPEED                440

/* 最低速度（防止堵转） */
#define TRACK_MIN_SPEED                0

/* P 增益：error × KP = 速度修正量 */
#define TRACK_KP                       60

/* D 增益：(error - prev_error) × KD = 阻尼/预判 */
#define TRACK_KD                       12

/* 左右轮平衡：右轮偏快 → < 1.0，左轮偏快 → > 1.0 */
#define TRACK_BALANCE_L                1.00f
#define TRACK_BALANCE_R                1.00f

/*
 * 传感器位置权重
 * X1...X8, 索引 0...7. X1/X8 禁用，权重置 0
 * 负值 = 左侧, 正值 = 右侧, 绝对值越大越靠外
 */
#define TRACK_WEIGHTS_INIT             {0, -5, -3, -1, 1, 3, 5, 0}

/* ============================================================
 *  电机
 * ============================================================ */
/* 急刹车反向 PWM */
#define BRAKE_PWM                      800
#define BRAKE_DURATION_MS              200

/* PWM 满量程 */
#define MOTOR_SPEED_MAX                1000

/* 电机方向反转 (0=正常, 1=反转) */
#define LEFT_MOTOR_REVERSED            0U
#define RIGHT_MOTOR_REVERSED           0U

/* ============================================================
 *  主循环
 * ============================================================ */
/* 主循环延时 (cycles @ 32MHz), 32000 ≈ 1ms */
#define TRACK_LOOP_DELAY_CYCLES        32000U

/* ============================================================
 *  按钮 (S1)
 * ============================================================ */
#define BUTTON_GPIO_PORT               GPIOA
#define BUTTON_GPIO_PIN                DL_GPIO_PIN_18
#define BUTTON_PINCM                   IOMUX_PINCM40
/* 按下为低电平，上拉 */

#endif /* CAR_CONFIG_H_ */
