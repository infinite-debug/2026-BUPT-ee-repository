#ifndef GREY_H_
#define GREY_H_

#include <stdint.h>

/*
 * Pattern:
 *   bit0...bit7 = X1...X8, from left to right
 *   only X2...X7 (bits 1...6) are sampled
 *   X1 and X8 always remain 0
 *   1 = this probe detects the black line
 *   0 = this probe sees the configured white-cloth level
 */
extern volatile uint8_t g_grey_raw_pattern;
extern volatile uint8_t g_grey_line_pattern;

void grey_init(void);
uint8_t grey_read_middle6(void);

/* Convert the six active raw readings into "black line detected" bits. */
uint8_t grey_raw_to_line_pattern(uint8_t raw_pattern);

#endif /* GREY_H_ */
