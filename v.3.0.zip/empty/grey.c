#include "grey.h"

#include <stdint.h>

#include "car_config.h"

volatile uint8_t g_grey_raw_pattern;
volatile uint8_t g_grey_line_pattern;

static void select_cd4051(uint8_t select_code)
{
    uint32_t selected_pins = 0U;
    const uint32_t select_mask =
        GREY_AD0_PIN | GREY_AD1_PIN | GREY_AD2_PIN;

    if ((select_code & 0x01U) != 0U) {
        selected_pins |= GREY_AD0_PIN;
    }
    if ((select_code & 0x02U) != 0U) {
        selected_pins |= GREY_AD1_PIN;
    }
    if ((select_code & 0x04U) != 0U) {
        selected_pins |= GREY_AD2_PIN;
    }

    DL_GPIO_clearPins(GREY_SELECT_PORT, select_mask);
    DL_GPIO_setPins(GREY_SELECT_PORT, selected_pins);
    delay_cycles(GREY_SETTLE_DELAY_CYCLES);
}

static uint8_t read_raw_level(void)
{
    return (DL_GPIO_readPins(GREY_OUT_PORT, GREY_OUT_PIN) != 0U) ? 1U : 0U;
}

uint8_t grey_raw_to_line_pattern(uint8_t raw_pattern)
{
    uint8_t line_pattern;

    /*
     * A raw bit equal to the reflected-light/white-cloth level becomes 0.
     * Only a bit different from that level becomes 1, meaning that the
     * selected probe sees the black line (no reflected light).
     *
     * Always clear X1 and X8 so either outer probe can never affect tracking.
     */
    if (GREY_WHITE_LEVEL != 0U) {
        line_pattern = (uint8_t) ~raw_pattern;
    } else {
        line_pattern = raw_pattern;
    }

    return (uint8_t) (line_pattern & TRACK_SENSOR_MASK);
}

void grey_init(void)
{
    DL_GPIO_clearPins(GREY_SELECT_PORT,
        GREY_AD0_PIN | GREY_AD1_PIN | GREY_AD2_PIN);
    g_grey_raw_pattern = 0U;
    g_grey_line_pattern = 0U;
}

uint8_t grey_read_middle6(void)
{
    uint8_t raw_pattern = 0U;
    uint8_t i;

    /*
     * CD4051 mapping:
     * select 001...110 -> X2...X7.
     *
     * X1 (000) and X8 (111) are deliberately not selected. A broken X8
     * therefore cannot create a false turn or prevent lost-line stopping.
     */
    for (i = GREY_CHANNEL_FIRST; i <= GREY_CHANNEL_LAST; i++) {
        select_cd4051(i);
        if (read_raw_level() != 0U) {
            raw_pattern |= (uint8_t) (1U << i);
        }
    }

    g_grey_raw_pattern = raw_pattern;
    g_grey_line_pattern = grey_raw_to_line_pattern(raw_pattern);

    return g_grey_line_pattern;
}
