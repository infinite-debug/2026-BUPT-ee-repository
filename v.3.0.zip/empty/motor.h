#ifndef MOTOR_H_
#define MOTOR_H_

#include <stdint.h>

void motor_init(void);
void motor_set_speeds(int16_t left_speed, int16_t right_speed);
void motor_stop(void);
void motor_brake(void);
void motor_short_brake(void);

#endif /* MOTOR_H_ */
