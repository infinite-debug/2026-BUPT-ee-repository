#include "track.h"

#include <stdint.h>

#include "car_config.h"
#include "grey.h"
#include "motor.h"

static int16_t g_previous_error;

volatile uint8_t g_track_pattern;
volatile int16_t g_track_left_speed;
volatile int16_t g_track_right_speed;
volatile TrackState g_track_state;

static int16_t clamp_forward_speed(int32_t speed)
{
    if (speed < 0) {
        return 0;
    }
    if (speed > TRACK_MAX_SPEED) {
        return TRACK_MAX_SPEED;
    }
    return (int16_t) speed;
}

static bool is_one_contiguous_black_area(uint8_t pattern)
{
    /*
     * A normal single track line produces one continuous group of 1 bits.
     * Reject separated groups, which usually indicate noise or a bad probe.
     */
    while (((pattern & 0x01U) == 0U) && (pattern != 0U)) {
        pattern >>= 1U;
    }
    while ((pattern & 0x01U) != 0U) {
        pattern >>= 1U;
    }

    return pattern == 0U;
}

static void stop_car(TrackState state)
{
    motor_stop();
    g_previous_error = 0;
    g_track_left_speed = 0;
    g_track_right_speed = 0;
    g_track_state = state;
}

TrackCommand track_calculate_command(uint8_t pattern, int16_t previous_error)
{
    static const int16_t weights[8] = {-7, -5, -3, -1, 1, 3, 5, 7};
    TrackCommand command = {0, 0, 0, TRACK_STATE_INVALID_PATTERN, false};
    int32_t weighted_sum = 0;
    int32_t correction;
    uint8_t count = 0U;
    uint8_t i;

    /*
     * Use only X2...X7. This also protects the controller if a caller passes
     * a stale X1/X8 bit from an older eight-channel reader.
     */
    pattern &= TRACK_SENSOR_MASK;

    /*
     * 00000000: all six active probes see white cloth -> lost line.
     * 01111110: all six active probes see low reflection -> likely suspended.
     *
     * Both states must stop before the weighted average is calculated.
     * Otherwise the all-dark pattern has a zero average and could look centered.
     */
    if (pattern == 0x00U) {
        command.state = TRACK_STATE_WHITE_LOST;
        return command;
    }
    if (pattern == TRACK_ALL_DARK_PATTERN) {
        command.state = TRACK_STATE_ALL_DARK;
        return command;
    }
    if (!is_one_contiguous_black_area(pattern)) {
        command.state = TRACK_STATE_INVALID_PATTERN;
        return command;
    }

    /*
     * The user's track is centered only when X4 and X5 see black.
     * Handle this exact pattern explicitly, so it is the defined straight
     * command rather than an accidental result of symmetric weight averaging.
     */
    if (pattern == TRACK_CENTER_PATTERN) {
        command.left_speed = TRACK_BASE_SPEED;
        command.right_speed = TRACK_BASE_SPEED;
        command.error = 0;
        command.state = TRACK_STATE_VALID_LINE;
        command.line_found = true;
        return command;
    }

    for (i = 1U; i <= 6U; i++) {
        if ((pattern & (uint8_t) (1U << i)) != 0U) {
            weighted_sum += weights[i];
            count++;
        }
    }

    /*
     * Any other symmetric wide-dark area is ambiguous. Do not let its zero
     * weighted average become another straight command.
     */
    if (weighted_sum == 0) {
        command.state = TRACK_STATE_INVALID_PATTERN;
        return command;
    }

    command.error = (int16_t) (weighted_sum / count);
    correction = (int32_t) TRACK_KP * command.error +
                 (int32_t) TRACK_KD * (command.error - previous_error);

    /*
     * Negative error: line is on the left -> left wheel slower.
     * Positive error: line is on the right -> right wheel slower.
     */
    command.left_speed =
        clamp_forward_speed((int32_t) TRACK_BASE_SPEED + correction);
    command.right_speed =
        clamp_forward_speed((int32_t) TRACK_BASE_SPEED - correction);
    command.state = TRACK_STATE_VALID_LINE;
    command.line_found = true;

    return command;
}

void track_init(void)
{
    g_previous_error = 0;
    g_track_pattern = 0U;
    g_track_left_speed = 0;
    g_track_right_speed = 0;
    g_track_state = TRACK_STATE_WHITE_LOST;
    motor_stop();
}

void track_update(void)
{
    uint8_t pattern = grey_read_middle6();
    TrackCommand command =
        track_calculate_command(pattern, g_previous_error);

    g_track_pattern = pattern;

    if (!command.line_found) {
        stop_car(command.state);
        return;
    }

    g_track_left_speed = command.left_speed;
    g_track_right_speed = command.right_speed;
    g_track_state = command.state;

    motor_set_speeds(command.left_speed, command.right_speed);
    g_previous_error = command.error;
}
