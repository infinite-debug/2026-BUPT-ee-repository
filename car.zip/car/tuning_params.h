/**
 * tuning_params.h — 所有可调参数集中管理
 *
 * 用法: 各 .c 文件 include 本文件即可使用全部命名常量。
 *       需要调参时只需修改这一个文件，不用到处翻代码。
 */

#ifndef __TUNING_PARAMS_H
#define __TUNING_PARAMS_H

/* ═══════════════════════════════════════════════════════════════════════
 * 1. 系统时钟
 * ═══════════════════════════════════════════════════════════════════════ */
#define SYSTICK_PERIOD          32000       /* SysTick 重载值 (32MHz / 1000Hz) */
#define CYCLES_PER_US           32          /* 每微秒 CPU 周期数 (32MHz) */

/* ═══════════════════════════════════════════════════════════════════════
 * 2. 电机 PWM
 * ═══════════════════════════════════════════════════════════════════════ */
#define PWM_PERIOD              9999        /* TIMG PWM 周期 */

/* ═══════════════════════════════════════════════════════════════════════
 * 3. 编码器
 * ═══════════════════════════════════════════════════════════════════════ */
#define ENC_PPR                 13          /* 编码器每圈脉冲数 */
#define ENC_GEAR_RATIO          20          /* 减速比 */
#define ENC_CPR                 (ENC_PPR * ENC_GEAR_RATIO)  /* 每圈总脉冲 */
#define ENC_RPM_SCALE           60000.0f    /* RPM 换算系数 (ms→min) */
#define ENC_SAMPLE_MS           10          /* 编码器采样周期 (ms) */

/* ═══════════════════════════════════════════════════════════════════════
 * 4. 车辆物理参数
 * ═══════════════════════════════════════════════════════════════════════ */
#define WHEEL_DIAMETER_MM       65.0f       /* 车轮直径 (mm) */
#define WHEEL_TRACK_MM          140.0f      /* 轮距 (mm) */
#define MM_PER_COUNT            (3.1416f * WHEEL_DIAMETER_MM / ENC_CPR)

/* ═══════════════════════════════════════════════════════════════════════
 * 5. 灰度传感器
 * ═══════════════════════════════════════════════════════════════════════ */
#define GRAY_COUNT              8           /* 传感器总路数 */
#define GRAY_SETTLE_TIME_US     50U         /* 通道切换后稳定等待 (us) */
#define GRAY_LINE_LEVEL         0U          /* 黑线对应 OUT 电平 */

/* ═══════════════════════════════════════════════════════════════════════
 * 6. 巡线控制
 * ═══════════════════════════════════════════════════════════════════════ */
#define TRACK_STRAIGHT_RANGE            1       /* error ∈ [-1,+1] 视为直行 */
#define TRACK_INTERSECTION_MIN_COUNT    3       /* ≥3 路检测到黑线 → 路口 */
#define TRACK_INTERSECTION_DEBOUNCE     4       /* 连续 N 次满足 → 确认路口 */
#define TRACK_INTERSECTION_COOLDOWN_MS  500     /* 两次路口检测间隔 (ms) */

/* 灰度传感器权重 (四路: X3, X4, X5, X6) */
#define GRAY_WEIGHT_X3  -3
#define GRAY_WEIGHT_X4  -1
#define GRAY_WEIGHT_X5   1
#define GRAY_WEIGHT_X6   3

/* ═══════════════════════════════════════════════════════════════════════
 * 7. 串级 PID — 外环 (巡线 error → 目标 RPM)
 * ═══════════════════════════════════════════════════════════════════════ */
#define PID_OUTER_KP            80.0f       /* 外环 Kp */
#define PID_OUTER_KD            12.0f       /* 外环 Kd */
#define PID_OUTER_IMAX          0.0f        /* 外环积分限幅 (0=禁用) */
#define PID_OUTER_RPM_MIN       -400        /* 外环输出下限 (RPM) */
#define PID_OUTER_RPM_MAX       400         /* 外环输出上限 (RPM) */

/* ═══════════════════════════════════════════════════════════════════════
 * 8. 串级 PID — 内环 (RPM 偏差 → PWM)
 * ═══════════════════════════════════════════════════════════════════════ */
#define PID_INNER_KP            20.0f       /* 内环 Kp */
#define PID_INNER_KI            2.0f        /* 内环 Ki */
#define PID_INNER_KD            0.0f        /* 内环 Kd */
#define PID_INNER_OUT_MAX       10000       /* 内环输出限幅 (±PWM) */
#define PID_DEADBAND_RPM        15          /* 死区: |RPM|<此值强制置零 */
#define PID_NEAR_ZERO_RPM       10.0f       /* 接近静止的 RPM 阈值 */

/* ═══════════════════════════════════════════════════════════════════════
 * 9. 巡线丢线恢复策略
 * ═══════════════════════════════════════════════════════════════════════ */
#define LOST_PHASE1_MS          300         /* 阶段1: 保持最后有效 error */
#define LOST_PHASE2_MS          800         /* 阶段2: error 偏移 */
#define LOST_PHASE2_OFFSET      -0.3f       /* 阶段2 偏移量 */
#define LOST_PHASE3_MS          1300        /* 阶段3: 反向偏移 */
#define LOST_PHASE3_OFFSET      0.3f        /* 阶段3 偏移量 */
#define LOST_PHASE4_MS          2000        /* 阶段4: 振荡搜索 */
#define LOST_PHASE4_PERIOD      300         /* 阶段4 振荡周期 (ms) */
#define LOST_PHASE4_AMP         0.5f        /* 阶段4 振幅 */

#define LINE_RPM_MIN_ABS        30          /* 最低转速绝对值 (防堵转) */
#define LINE_RPM_MAX            400         /* 最高转速限制 */

/* ═══════════════════════════════════════════════════════════════════════
 * 10. 状态机时序 (ms)
 * ═══════════════════════════════════════════════════════════════════════ */
#define FSM_T_LOAD_DETECT       1000        /* 装药检测等待 */
#define FSM_T_AT_INTER_HOLD     200         /* 路口停车稳定 */
#define FSM_T_APPROACH_MS       800         /* 驶向病房直行时间 */
#define FSM_T_STOP_WARD         2000        /* 病房前停车展示 */
#define FSM_T_WAIT_UNLOAD       8000        /* 等待卸药超时 */
#define FSM_T_EXIT_ROTATE       1500        /* 病房内掉头时间 */
#define FSM_T_MISSION_MAX       60000       /* 单次任务总超时 */
#define FSM_T_PHARMACY_HOLD     3000        /* 到达药房后停留 */
#define FSM_T_INIT_ACTION_MS    10          /* 状态刚进入时的初始动作窗口 */
#define FSM_T_LOST_THRESHOLD_MS 2000        /* 巡线丢线超时 → 故障 */

/* ═══════════════════════════════════════════════════════════════════════
 * 11. 状态机转速
 * ═══════════════════════════════════════════════════════════════════════ */
#define FSM_SPEED_TURN          150         /* 原地转弯转速 (RPM) */
#define FSM_SPEED_APPROACH      200         /* 驶向病房转速 (RPM) */
#define FSM_SPEED_EXIT          200         /* 驶离病房转速 (RPM) */
#define FSM_TURN_DURATION_MS    1200        /* 转弯持续时间 (ms) */
#define FSM_RETURN_TURN_DUR_MS  1200        /* 返航转弯持续时间 (ms) */

/* ═══════════════════════════════════════════════════════════════════════
 * 12. 路口扫描
 * ═══════════════════════════════════════════════════════════════════════ */
#define SCAN_ROTATE_SPEED       120         /* 扫描旋转转速 (RPM) */
#define SCAN_LEFT_DURATION_MS   600         /* 左转持续时间 */
#define SCAN_READ_DURATION_MS   800         /* 读取 OpenMV 数据窗口 */
#define SCAN_RIGHT_DURATION_MS  1200        /* 右转持续时间 (需覆盖 2× 转角) */
#define SCAN_RETURN_DURATION_MS 600         /* 回正持续时间 */
#define SCAN_MAX_WARDS_PER_SIDE 4           /* 单侧最多识别病房数 */

/* ═══════════════════════════════════════════════════════════════════════
 * 13. 超声波测距
 * ═══════════════════════════════════════════════════════════════════════ */
#define ULTRASONIC_TRIG_US              15      /* Trig 脉冲宽度 (us) */
#define ULTRASONIC_ECHO_TIMEOUT_MS      5       /* 等 Echo 变高超时 (ms) */
#define ULTRASONIC_ECHO_LOW_TIMEOUT_MS  50      /* 等 Echo 变低超时 (ms) */
#define ULTRASONIC_SPEED_FACTOR         17.24f  /* 声速换算: mm/ms */

/* ═══════════════════════════════════════════════════════════════════════
 * 14. 串口通信 (OpenMV)
 * ═══════════════════════════════════════════════════════════════════════ */
#define UART_BUS_CLK            32000000    /* UART 总线时钟 (Hz) */
#define UART_VISION_BAUD        9600        /* OpenMV 波特率 */
#define UART_DEBUG_BAUD          115200      /* 调试串口波特率 */
#define UART_DEBUG_BUF_SIZE      128         /* 调试串口缓冲区字节数 */
#define WARD_NUMBER_MIN         1           /* 病房号下限 */
#define WARD_NUMBER_MAX         8           /* 病房号上限 */
#define UART_RX_BUF_SIZE        32          /* OpenMV 接收缓冲区字节数 */

/* ═══════════════════════════════════════════════════════════════════════
 * 15. 路径规划
 * ═══════════════════════════════════════════════════════════════════════ */
#define PATH_NEAR_WARD_MAX      2           /* 1-2 号房为近端固定位置 */
#define PATH_BRANCH_WARD_MIN    5           /* 5-8 号房在 Y 分叉远端 */
#define PATH_BRANCH_MIN_INTERS  3           /* 分支节点最少已过路口数 */

/* ═══════════════════════════════════════════════════════════════════════
 * 16. 主循环
 * ═══════════════════════════════════════════════════════════════════════ */
#define LOOP_PERIOD_2MS         2           /* 2ms: 巡线+PID+编码器 */
#define LOOP_PERIOD_10MS        10          /* 10ms: 状态机 */
#define LOOP_PERIOD_50MS        50          /* 50ms: LED */
#define BOOT_DELAY_MS           200         /* 开机指示延时 */
#define BUTTON_DEBOUNCE_MS      200         /* 按键消抖延时 */
#define SCAN_REQ_INTERVAL_MS    2000        /* 空闲时扫描请求间隔 */
#define ERROR_DIVISOR           3.0f        /* 灰度 error 归一化除数 */

#endif /* __TUNING_PARAMS_H */
