/**
 * main.c — 智能送药小车（Cascade PID 版）
 *
 * 左右轮各一个 CascadePID 结构体，
 * 巡线时外环 PID(error→RPM)，转弯时旁路外环直接设转速。
 */

#include "ti_msp_dl_config.h"
#include "config.h"
#include "lib/system.h"
#include "lib/delay.h"
#include "lib/uart.h"
#include "lib/motor.h"
#include "lib/motion.h"
#include "lib/gray.h"
#include "app/track.h"
#include "lib/led_indicator.h"
#include "lib/encoder.h"
#include "lib/cascade_pid.h"
#include "lib/oled.h"
#include "lib/ultrasonic.h"
#include "lib/servo.h"
#include "app/line_controller.h"
#include "app/uart_protocol.h"
#include "app/intersection_scanner.h"
#include "app/path_planner.h"
#include "app/delivery_fsm.h"
#include <string.h>

CascadePID_t                 g_cp_L, g_cp_R;
uint8_t                      g_line_active = 0;
static Encoder_t             g_enc_L, g_enc_R;
UARTProtocol_t               g_uart_proto;
static IntersectionScanner_t g_scanner;
static DeliveryFSM_t         g_fsm;

int main(void)
{
    SYSCFG_DL_init();
    System_ClockInit();
    Delay_Init();

    LED_Init();
    Motion_Init();
    Encoder_InitL(&g_enc_L, ENC_PPR, ENC_GEAR_RATIO, ENC_SAMPLE_MS);
    Encoder_InitR(&g_enc_R, ENC_PPR, ENC_GEAR_RATIO, ENC_SAMPLE_MS);
    OLED_Init();
    Servo_Init();

    /* 左右轮各一个串级 PID */
    CascadePID_Init(&g_cp_L,
        PID_OUTER_KP, PID_OUTER_KD, PID_OUTER_IMAX,
        PID_OUTER_RPM_MIN, PID_OUTER_RPM_MAX,
        PID_INNER_KP, PID_INNER_KI, PID_INNER_KD,
        PID_INNER_OUT_MAX, PID_DEADBAND_RPM);
    CascadePID_Init(&g_cp_R, PID_OUTER_KP, PID_OUTER_KD, PID_OUTER_IMAX,
                    PID_OUTER_RPM_MIN, PID_OUTER_RPM_MAX,
                    PID_INNER_KP, PID_INNER_KI, PID_INNER_KD,
                    PID_INNER_OUT_MAX, PID_DEADBAND_RPM);

    UARTProtocol_Init(&g_uart_proto);
    IntersectionScanner_Init(&g_scanner, &g_uart_proto);
    DeliveryFSM_Init(&g_fsm, &g_uart_proto, &g_scanner);

    DL_GPIO_setPins(BOARD_LED_PORT, BOARD_LED_PWR_PIN);
    delay_ms(BOOT_DELAY_MS);
    DL_GPIO_clearPins(BOARD_LED_PORT, BOARD_LED_PWR_PIN);

    UART_Printf("\r\n=== Medicine Delivery Car ===\r\n");
    UART_Printf("MSPM0G3507 Cascade PID | Gray+Encoder\r\n");
    UART_Printf("cmd: 1-8=go u=unload s=stat x=stop\r\n");

    LED_SetPattern(LED_ALL_OFF);
    OLED_ShowString(1, 1, "Delivery Car", 1);
    OLED_ShowString(2, 1, "Cascade PID", 1);
    OLED_ShowString(3, 1, "Ready.", 1);

    UARTProtocol_SendScanReq();

    uint32_t last_2ms = 0, last_10ms = 0, last_50ms = 0, last_scan = g_sys_ms;
    char cmd_buf[32];
    float g_err = 0, g_rpm_L = 0, g_rpm_R = 0;

    while (1) {
        uint32_t now = g_sys_ms;

        /* ═══ 2ms ═══ */
        if (now - last_2ms >= LOOP_PERIOD_2MS) {
            last_2ms = now;

            Track_Run();   /* 灰度 4 路读取 + 质心 */
            Encoder_Update(&g_enc_L);
            Encoder_Update(&g_enc_R);

            g_err  = (float)Track_GetError() / ERROR_DIVISOR;
            g_rpm_L = Encoder_GetRPM(&g_enc_L);
            g_rpm_R = Encoder_GetRPM(&g_enc_R);
            uint8_t lost    = Track_IsLineLost();

            uint8_t bypass = !g_line_active;

            int16_t pwm_L = CascadePID_Update(&g_cp_L, g_err, g_rpm_L, bypass);
            int16_t pwm_R = CascadePID_Update(&g_cp_R, g_err, g_rpm_R, bypass);

            Motor_Left(pwm_L);
            Motor_Right(pwm_R);
        }

        /* ═══ 10ms: FSM ═══ */
        if (now - last_10ms >= LOOP_PERIOD_10MS) {
            last_10ms = now;
            DeliveryFSM_Update(&g_fsm, now);
        }

        /* ═══ 50ms: LED ═══ */
        if (now - last_50ms >= LOOP_PERIOD_50MS) { last_50ms = now; LED_Update(); }

        /* ═══ 串口命令 ═══ */
        if (UART_ReadLine(cmd_buf, sizeof(cmd_buf))) {
            switch (cmd_buf[0]) {
            case '1': case '2': case '3': case '4':
            case '5': case '6': case '7': case '8':
                DeliveryFSM_StartMission(&g_fsm, cmd_buf[0] - '0');
                break;
            case 'u': DeliveryFSM_ConfirmUnload(&g_fsm); break;
            case 's':
                DeliveryFSM_PrintStatus(&g_fsm);
                UART_Printf("[PID] L=%dRPM(%d) R=%dRPM(%d) err=%.2f\r\n",
                    (int)g_rpm_L, (int)g_cp_L.target_rpm,
                    (int)g_rpm_R, (int)g_cp_R.target_rpm, g_err);
                break;
            case 'x': DeliveryFSM_EmergencyStop(&g_fsm); break;
            }
        }

        /* ═══ 按键急停 ═══ */
        if (!DL_GPIO_readPins(BUTTON_S1_PORT, BUTTON_S1_PIN)) {
            if (g_fsm.state != FSM_IDLE)
                DeliveryFSM_EmergencyStop(&g_fsm);
            delay_ms(BUTTON_DEBOUNCE_MS);
        }

        /* ═══ OpenMV 自动启动 ═══ */
        if (g_fsm.state == FSM_IDLE && UARTProtocol_HasNewWard(&g_uart_proto)) {
            uint8_t w = UARTProtocol_GetWard(&g_uart_proto);
            DeliveryFSM_StartMission(&g_fsm, w);
            UART_Printf("[AUTO] Ward %d, mission start\r\n", w);
        }

        if (g_fsm.state == FSM_IDLE && (g_sys_ms - last_scan) > SCAN_REQ_INTERVAL_MS) {
            last_scan = g_sys_ms;
            UARTProtocol_SendScanReq();
        }
    }
}
