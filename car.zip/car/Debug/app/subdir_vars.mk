################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../app/delivery_fsm.c \
../app/intersection_scanner.c \
../app/line_controller.c \
../app/path_planner.c \
../app/track.c \
../app/uart_protocol.c 

C_DEPS += \
./app/delivery_fsm.d \
./app/intersection_scanner.d \
./app/line_controller.d \
./app/path_planner.d \
./app/track.d \
./app/uart_protocol.d 

OBJS += \
./app/delivery_fsm.o \
./app/intersection_scanner.o \
./app/line_controller.o \
./app/path_planner.o \
./app/track.o \
./app/uart_protocol.o 

OBJS__QUOTED += \
"app\delivery_fsm.o" \
"app\intersection_scanner.o" \
"app\line_controller.o" \
"app\path_planner.o" \
"app\track.o" \
"app\uart_protocol.o" 

C_DEPS__QUOTED += \
"app\delivery_fsm.d" \
"app\intersection_scanner.d" \
"app\line_controller.d" \
"app\path_planner.d" \
"app\track.d" \
"app\uart_protocol.d" 

C_SRCS__QUOTED += \
"../app/delivery_fsm.c" \
"../app/intersection_scanner.c" \
"../app/line_controller.c" \
"../app/path_planner.c" \
"../app/track.c" \
"../app/uart_protocol.c" 


