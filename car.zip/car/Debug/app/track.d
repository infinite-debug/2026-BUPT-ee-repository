# FIXED

app/track.o: ../app/track.c ../app/track.h ../lib/gray.h \
 ../tuning_params.h
../app/track.h:
../lib/gray.h:
../tuning_params.h:
