################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
build-894269022: ../car.syscfg
	@echo 'SysConfig - building file: "$<"'
	"C:/ti/ccs2100/ccs/utils/sysconfig_1.28.0/sysconfig_cli.bat" --script "C:/Users/23958/workspace_ccstheia/car/car.syscfg" -o "syscfg" --compiler ticlang
	@echo 'Finished building: "$<"'
	@echo ' '

syscfg/device_linker.cmd: build-894269022 ../car.syscfg
syscfg/device.opt: build-894269022
syscfg/device.cmd.genlibs: build-894269022
syscfg/ti_msp_dl_config.c: build-894269022
syscfg/ti_msp_dl_config.h: build-894269022
syscfg/Event.dot: build-894269022
syscfg: build-894269022

syscfg/%.o: ./syscfg/%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Arm Compiler - building file: "$<"'
	"C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-armllvm_5.1.1.LTS/bin/tiarmclang.exe" -c -mfloat-abi=soft -mlittle-endian -Og -I"C:/Users/23958/workspace_ccstheia/car" -I"C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-armllvm_5.1.1.LTS/include" -I"C:/ti/mspm0_sdk_2_11_00_07/source/third_party/CMSIS/Include" -I"C:/ti/mspm0_sdk_2_11_00_07/source" -I"C:/ti/mspm0_sdk_2_11_00_07/source/ti/driverlib" -I"C:/ti/mspm0_sdk_2_11_00_07/source/third_party/CMSIS/Core/Include" -D__MSPM0G3507__ -g -MMD -MP -MF"syscfg/$(basename $(<F)).d_raw" -MT"$(@)" -I"C:/Users/23958/workspace_ccstheia/car/Debug/syscfg"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '

startup_mspm0g350x_ticlang.o: C:/ti/mspm0_sdk_2_11_00_07/source/ti/devices/msp/m0p/startup_system_files/ticlang/startup_mspm0g350x_ticlang.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Arm Compiler - building file: "$<"'
	"C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-armllvm_5.1.1.LTS/bin/tiarmclang.exe" -c -mfloat-abi=soft -mlittle-endian -Og -I"C:/Users/23958/workspace_ccstheia/car" -I"C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-armllvm_5.1.1.LTS/include" -I"C:/ti/mspm0_sdk_2_11_00_07/source/third_party/CMSIS/Include" -I"C:/ti/mspm0_sdk_2_11_00_07/source" -I"C:/ti/mspm0_sdk_2_11_00_07/source/ti/driverlib" -I"C:/ti/mspm0_sdk_2_11_00_07/source/third_party/CMSIS/Core/Include" -D__MSPM0G3507__ -g -MMD -MP -MF"$(basename $(<F)).d_raw" -MT"$(@)" -I"C:/Users/23958/workspace_ccstheia/car/Debug/syscfg"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '

%.o: ../%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Arm Compiler - building file: "$<"'
	"C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-armllvm_5.1.1.LTS/bin/tiarmclang.exe" -c -mfloat-abi=soft -mlittle-endian -Og -I"C:/Users/23958/workspace_ccstheia/car" -I"C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-armllvm_5.1.1.LTS/include" -I"C:/ti/mspm0_sdk_2_11_00_07/source/third_party/CMSIS/Include" -I"C:/ti/mspm0_sdk_2_11_00_07/source" -I"C:/ti/mspm0_sdk_2_11_00_07/source/ti/driverlib" -I"C:/ti/mspm0_sdk_2_11_00_07/source/third_party/CMSIS/Core/Include" -D__MSPM0G3507__ -g -MMD -MP -MF"$(basename $(<F)).d_raw" -MT"$(@)" -I"C:/Users/23958/workspace_ccstheia/car/Debug/syscfg"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '


