# FIXED

lib/speed_controller.o: ../lib/speed_controller.c \
 ../lib/speed_controller.h ../lib/pid.h \
 C:/Users/23958/workspace_ccstheia/car/tuning_params.h
../lib/speed_controller.h:
../lib/pid.h:
C:/Users/23958/workspace_ccstheia/car/tuning_params.h:
