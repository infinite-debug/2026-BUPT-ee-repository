################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../lib/cascade_pid.c \
../lib/delay.c \
../lib/encoder.c \
../lib/gray.c \
../lib/led_indicator.c \
../lib/motion.c \
../lib/motor.c \
../lib/oled.c \
../lib/pid.c \
../lib/speed_controller.c \
../lib/uart.c \
../lib/ultrasonic.c 

C_DEPS += \
./lib/cascade_pid.d \
./lib/delay.d \
./lib/encoder.d \
./lib/gray.d \
./lib/led_indicator.d \
./lib/motion.d \
./lib/motor.d \
./lib/oled.d \
./lib/pid.d \
./lib/speed_controller.d \
./lib/uart.d \
./lib/ultrasonic.d 

OBJS += \
./lib/cascade_pid.o \
./lib/delay.o \
./lib/encoder.o \
./lib/gray.o \
./lib/led_indicator.o \
./lib/motion.o \
./lib/motor.o \
./lib/oled.o \
./lib/pid.o \
./lib/speed_controller.o \
./lib/uart.o \
./lib/ultrasonic.o 

OBJS__QUOTED += \
"lib\cascade_pid.o" \
"lib\delay.o" \
"lib\encoder.o" \
"lib\gray.o" \
"lib\led_indicator.o" \
"lib\motion.o" \
"lib\motor.o" \
"lib\oled.o" \
"lib\pid.o" \
"lib\speed_controller.o" \
"lib\uart.o" \
"lib\ultrasonic.o" 

C_DEPS__QUOTED += \
"lib\cascade_pid.d" \
"lib\delay.d" \
"lib\encoder.d" \
"lib\gray.d" \
"lib\led_indicator.d" \
"lib\motion.d" \
"lib\motor.d" \
"lib\oled.d" \
"lib\pid.d" \
"lib\speed_controller.d" \
"lib\uart.d" \
"lib\ultrasonic.d" 

C_SRCS__QUOTED += \
"../lib/cascade_pid.c" \
"../lib/delay.c" \
"../lib/encoder.c" \
"../lib/gray.c" \
"../lib/led_indicator.c" \
"../lib/motion.c" \
"../lib/motor.c" \
"../lib/oled.c" \
"../lib/pid.c" \
"../lib/speed_controller.c" \
"../lib/uart.c" \
"../lib/ultrasonic.c" 


