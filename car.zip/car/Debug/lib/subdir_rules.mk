################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
lib/%.o: ../lib/%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Arm Compiler - building file: "$<"'
	"C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-armllvm_5.1.1.LTS/bin/tiarmclang.exe" -c -mfloat-abi=soft -mlittle-endian -Og -I"C:/Users/23958/workspace_ccstheia/car" -I"C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-armllvm_5.1.1.LTS/include" -I"C:/ti/mspm0_sdk_2_11_00_07/source/third_party/CMSIS/Include" -I"C:/ti/mspm0_sdk_2_11_00_07/source" -I"C:/ti/mspm0_sdk_2_11_00_07/source/ti/driverlib" -I"C:/ti/mspm0_sdk_2_11_00_07/source/third_party/CMSIS/Core/Include" -D__MSPM0G3507__ -g -MMD -MP -MF"lib/$(basename $(<F)).d_raw" -MT"$(@)" -I"C:/Users/23958/workspace_ccstheia/car/Debug/syscfg"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '


