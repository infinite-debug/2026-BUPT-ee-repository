/*
 * Copyright (c) 2023, Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ============ ti_msp_dl_config.h =============
 *  Configured MSPM0 DriverLib module declarations
 *
 *  DO NOT EDIT - This file is generated for the MSPM0G350X
 *  by the SysConfig tool.
 */
#ifndef ti_msp_dl_config_h
#define ti_msp_dl_config_h

#define CONFIG_MSPM0G350X
#define CONFIG_MSPM0G3507

#if defined(__ti_version__) || defined(__TI_COMPILER_VERSION__)
#define SYSCONFIG_WEAK __attribute__((weak))
#elif defined(__IAR_SYSTEMS_ICC__)
#define SYSCONFIG_WEAK __weak
#elif defined(__GNUC__)
#define SYSCONFIG_WEAK __attribute__((weak))
#endif

#include <ti/devices/msp/msp.h>
#include <ti/driverlib/driverlib.h>
#include <ti/driverlib/m0p/dl_core.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 *  ======== SYSCFG_DL_init ========
 *  Perform all required MSP DL initialization
 *
 *  This function should be called once at a point before any use of
 *  MSP DL.
 */


/* clang-format off */

#define POWER_STARTUP_DELAY                                                (16)


#define CPUCLK_FREQ                                                     32000000



/* Defines for MOTOR */
#define MOTOR_INST                                                         TIMG0
#define MOTOR_INST_IRQHandler                                   TIMG0_IRQHandler
#define MOTOR_INST_INT_IRQN                                     (TIMG0_INT_IRQn)
#define MOTOR_INST_CLK_FREQ                                             32000000
/* GPIO defines for channel 0 */
#define GPIO_MOTOR_C0_PORT                                                 GPIOA
#define GPIO_MOTOR_C0_PIN                                         DL_GPIO_PIN_12
#define GPIO_MOTOR_C0_IOMUX                                      (IOMUX_PINCM34)
#define GPIO_MOTOR_C0_IOMUX_FUNC                     IOMUX_PINCM34_PF_TIMG0_CCP0
#define GPIO_MOTOR_C0_IDX                                    DL_TIMER_CC_0_INDEX
/* GPIO defines for channel 1 */
#define GPIO_MOTOR_C1_PORT                                                 GPIOA
#define GPIO_MOTOR_C1_PIN                                         DL_GPIO_PIN_13
#define GPIO_MOTOR_C1_IOMUX                                      (IOMUX_PINCM35)
#define GPIO_MOTOR_C1_IOMUX_FUNC                     IOMUX_PINCM35_PF_TIMG0_CCP1
#define GPIO_MOTOR_C1_IDX                                    DL_TIMER_CC_1_INDEX




/* Defines for OLED */
#define OLED_INST                                                           I2C1
#define OLED_INST_IRQHandler                                     I2C1_IRQHandler
#define OLED_INST_INT_IRQN                                         I2C1_INT_IRQn
#define GPIO_OLED_SDA_PORT                                                 GPIOB
#define GPIO_OLED_SDA_PIN                                          DL_GPIO_PIN_3
#define GPIO_OLED_IOMUX_SDA                                      (IOMUX_PINCM16)
#define GPIO_OLED_IOMUX_SDA_FUNC                       IOMUX_PINCM16_PF_I2C1_SDA
#define GPIO_OLED_SCL_PORT                                                 GPIOB
#define GPIO_OLED_SCL_PIN                                          DL_GPIO_PIN_2
#define GPIO_OLED_IOMUX_SCL                                      (IOMUX_PINCM15)
#define GPIO_OLED_IOMUX_SCL_FUNC                       IOMUX_PINCM15_PF_I2C1_SCL


/* Defines for DEBUG */
#define DEBUG_INST                                                         UART0
#define DEBUG_INST_FREQUENCY                                            32000000
#define DEBUG_INST_IRQHandler                                   UART0_IRQHandler
#define DEBUG_INST_INT_IRQN                                       UART0_INT_IRQn
#define GPIO_DEBUG_RX_PORT                                                 GPIOA
#define GPIO_DEBUG_TX_PORT                                                 GPIOA
#define GPIO_DEBUG_RX_PIN                                         DL_GPIO_PIN_11
#define GPIO_DEBUG_TX_PIN                                         DL_GPIO_PIN_10
#define GPIO_DEBUG_IOMUX_RX                                      (IOMUX_PINCM22)
#define GPIO_DEBUG_IOMUX_TX                                      (IOMUX_PINCM21)
#define GPIO_DEBUG_IOMUX_RX_FUNC                       IOMUX_PINCM22_PF_UART0_RX
#define GPIO_DEBUG_IOMUX_TX_FUNC                       IOMUX_PINCM21_PF_UART0_TX
#define DEBUG_BAUD_RATE                                                 (115200)
#define DEBUG_IBRD_32_MHZ_115200_BAUD                                       (17)
#define DEBUG_FBRD_32_MHZ_115200_BAUD                                       (23)
/* Defines for VISION */
#define VISION_INST                                                        UART2
#define VISION_INST_FREQUENCY                                           32000000
#define VISION_INST_IRQHandler                                  UART2_IRQHandler
#define VISION_INST_INT_IRQN                                      UART2_INT_IRQn
#define GPIO_VISION_RX_PORT                                                GPIOB
#define GPIO_VISION_TX_PORT                                                GPIOB
#define GPIO_VISION_RX_PIN                                        DL_GPIO_PIN_16
#define GPIO_VISION_TX_PIN                                        DL_GPIO_PIN_15
#define GPIO_VISION_IOMUX_RX                                     (IOMUX_PINCM33)
#define GPIO_VISION_IOMUX_TX                                     (IOMUX_PINCM32)
#define GPIO_VISION_IOMUX_RX_FUNC                      IOMUX_PINCM33_PF_UART2_RX
#define GPIO_VISION_IOMUX_TX_FUNC                      IOMUX_PINCM32_PF_UART2_TX
#define VISION_BAUD_RATE                                                  (9600)
#define VISION_IBRD_32_MHZ_9600_BAUD                                       (208)
#define VISION_FBRD_32_MHZ_9600_BAUD                                        (21)





/* Port definition for Pin Group BOARD_LED */
#define BOARD_LED_PORT                                                   (GPIOA)

/* Defines for PWR: GPIOA.0 with pinCMx 1 on package pin 33 */
#define BOARD_LED_PWR_PIN                                        (DL_GPIO_PIN_0)
#define BOARD_LED_PWR_IOMUX                                       (IOMUX_PINCM1)
/* Port definition for Pin Group GRAY */
#define GRAY_PORT                                                        (GPIOA)

/* Defines for AD0: GPIOA.15 with pinCMx 37 on package pin 8 */
#define GRAY_AD0_PIN                                            (DL_GPIO_PIN_15)
#define GRAY_AD0_IOMUX                                           (IOMUX_PINCM37)
/* Defines for AD1: GPIOA.28 with pinCMx 3 on package pin 35 */
#define GRAY_AD1_PIN                                            (DL_GPIO_PIN_28)
#define GRAY_AD1_IOMUX                                            (IOMUX_PINCM3)
/* Defines for AD2: GPIOA.17 with pinCMx 39 on package pin 10 */
#define GRAY_AD2_PIN                                            (DL_GPIO_PIN_17)
#define GRAY_AD2_IOMUX                                           (IOMUX_PINCM39)
/* Defines for OUT: GPIOA.22 with pinCMx 47 on package pin 18 */
#define GRAY_OUT_PIN                                            (DL_GPIO_PIN_22)
#define GRAY_OUT_IOMUX                                           (IOMUX_PINCM47)
/* Port definition for Pin Group MOTOR_DIR */
#define MOTOR_DIR_PORT                                                   (GPIOA)

/* Defines for L_IN1: GPIOA.26 with pinCMx 59 on package pin 30 */
#define MOTOR_DIR_L_IN1_PIN                                     (DL_GPIO_PIN_26)
#define MOTOR_DIR_L_IN1_IOMUX                                    (IOMUX_PINCM59)
/* Defines for L_IN2: GPIOA.24 with pinCMx 54 on package pin 25 */
#define MOTOR_DIR_L_IN2_PIN                                     (DL_GPIO_PIN_24)
#define MOTOR_DIR_L_IN2_IOMUX                                    (IOMUX_PINCM54)
/* Defines for R_IN1: GPIOA.27 with pinCMx 60 on package pin 31 */
#define MOTOR_DIR_R_IN1_PIN                                     (DL_GPIO_PIN_27)
#define MOTOR_DIR_R_IN1_IOMUX                                    (IOMUX_PINCM60)
/* Defines for R_IN2: GPIOA.25 with pinCMx 55 on package pin 26 */
#define MOTOR_DIR_R_IN2_PIN                                     (DL_GPIO_PIN_25)
#define MOTOR_DIR_R_IN2_IOMUX                                    (IOMUX_PINCM55)
/* Port definition for Pin Group STATUS_LED */
#define STATUS_LED_PORT                                                  (GPIOB)

/* Defines for GREEN: GPIOB.4 with pinCMx 17 on package pin 52 */
#define STATUS_LED_GREEN_PIN                                     (DL_GPIO_PIN_4)
#define STATUS_LED_GREEN_IOMUX                                   (IOMUX_PINCM17)
/* Defines for RED: GPIOB.1 with pinCMx 13 on package pin 48 */
#define STATUS_LED_RED_PIN                                       (DL_GPIO_PIN_1)
#define STATUS_LED_RED_IOMUX                                     (IOMUX_PINCM13)
/* Defines for YELLOW: GPIOB.12 with pinCMx 29 on package pin 64 */
#define STATUS_LED_YELLOW_PIN                                   (DL_GPIO_PIN_12)
#define STATUS_LED_YELLOW_IOMUX                                  (IOMUX_PINCM29)
/* Port definition for Pin Group ENCODER */
#define ENCODER_PORT                                                     (GPIOB)

/* Defines for A: GPIOB.20 with pinCMx 48 on package pin 19 */
#define ENCODER_A_PIN                                           (DL_GPIO_PIN_20)
#define ENCODER_A_IOMUX                                          (IOMUX_PINCM48)
/* Defines for B: GPIOB.13 with pinCMx 30 on package pin 1 */
#define ENCODER_B_PIN                                           (DL_GPIO_PIN_13)
#define ENCODER_B_IOMUX                                          (IOMUX_PINCM30)
/* Port definition for Pin Group ENCODER_R */
#define ENCODER_R_PORT                                                   (GPIOB)

/* Defines for RA: GPIOB.8 with pinCMx 25 on package pin 60 */
#define ENCODER_R_RA_PIN                                         (DL_GPIO_PIN_8)
#define ENCODER_R_RA_IOMUX                                       (IOMUX_PINCM25)
/* Defines for RB: GPIOB.9 with pinCMx 26 on package pin 61 */
#define ENCODER_R_RB_PIN                                         (DL_GPIO_PIN_9)
#define ENCODER_R_RB_IOMUX                                       (IOMUX_PINCM26)
/* Port definition for Pin Group ULTRASONIC */
#define ULTRASONIC_PORT                                                  (GPIOB)

/* Defines for TRIG: GPIOB.7 with pinCMx 24 on package pin 59 */
#define ULTRASONIC_TRIG_PIN                                      (DL_GPIO_PIN_7)
#define ULTRASONIC_TRIG_IOMUX                                    (IOMUX_PINCM24)
/* Defines for ECHO: GPIOB.0 with pinCMx 12 on package pin 47 */
#define ULTRASONIC_ECHO_PIN                                      (DL_GPIO_PIN_0)
#define ULTRASONIC_ECHO_IOMUX                                    (IOMUX_PINCM12)
/* Defines for S1: GPIOA.18 with pinCMx 40 on package pin 11 */
#define BUTTON_S1_PORT                                                   (GPIOA)
#define BUTTON_S1_PIN                                           (DL_GPIO_PIN_18)
#define BUTTON_S1_IOMUX                                          (IOMUX_PINCM40)
/* Defines for UNLOAD: GPIOB.6 with pinCMx 23 on package pin 58 */
#define BUTTON_UNLOAD_PORT                                               (GPIOB)
#define BUTTON_UNLOAD_PIN                                        (DL_GPIO_PIN_6)
#define BUTTON_UNLOAD_IOMUX                                      (IOMUX_PINCM23)


/* clang-format on */

void SYSCFG_DL_init(void);
void SYSCFG_DL_initPower(void);
void SYSCFG_DL_GPIO_init(void);
void SYSCFG_DL_SYSCTL_init(void);
void SYSCFG_DL_MOTOR_init(void);
void SYSCFG_DL_OLED_init(void);
void SYSCFG_DL_DEBUG_init(void);
void SYSCFG_DL_VISION_init(void);


bool SYSCFG_DL_saveConfiguration(void);
bool SYSCFG_DL_restoreConfiguration(void);

#ifdef __cplusplus
}
#endif

#endif /* ti_msp_dl_config_h */
