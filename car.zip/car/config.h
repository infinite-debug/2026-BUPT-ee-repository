/**
 * config.h — 工程常量（向后兼容，实际参数见 tuning_params.h）
 */

#ifndef __CONFIG_H
#define __CONFIG_H

#include "tuning_params.h"

#endif
