/**
 * uart.h/c — 调试串口（MSPM0 UART0, 115200-8-N-1）
 *
 * XDS110 虚拟串口通过 UART0 收发 printf 和命令。
 * MSPM0 DriverLib API: DL_UART_xxx
 */

#ifndef __UART_H
#define __UART_H

#include "ti_msp_dl_config.h"

void UART_Init(void);
void UART_SendByte(uint8_t ch);
void UART_SendString(const char *str);
void UART_Printf(const char *fmt, ...);
int  UART_ReadLine(char *buf, uint16_t maxlen);

#endif
