#include "pid.h"

void PID_Init(PID_t *pid, float Kp, float Ki, float Kd,
              float dt, float out_max, float out_min)
{
    pid->Kp = Kp; pid->Ki = Ki; pid->Kd = Kd;
    pid->dt = dt;
    pid->output_max = out_max;
    pid->output_min = out_min;
    pid->integral_max = out_max;
    pid->integral_min = out_min;
    pid->sep_threshold = 0.0f;
    PID_Reset(pid);
}

void PID_SetTarget(PID_t *pid, float target) { pid->target = target; }
void PID_SetIntegralLimit(PID_t *pid, float max, float min)
    { pid->integral_max = max; pid->integral_min = min; }
void PID_SetSepThreshold(PID_t *pid, float t) { pid->sep_threshold = t; }

float PID_Update(PID_t *pid, float feedback)
{
    pid->feedback = feedback;
    float e = pid->target - feedback;
    pid->error = e;

    /* P */
    pid->p_term = pid->Kp * e;

    /* I — 积分分离 */
    if (pid->sep_threshold > 0.0f) {
        float abs_e = (e > 0) ? e : -e;
        if (abs_e <= pid->sep_threshold)
            pid->integral += e * pid->dt;
    } else {
        pid->integral += e * pid->dt;
    }
    if (pid->integral > pid->integral_max) pid->integral = pid->integral_max;
    if (pid->integral < pid->integral_min) pid->integral = pid->integral_min;
    pid->i_term = pid->Ki * pid->integral;

    /* D */
    float deriv = (e - pid->prev_error) / pid->dt;
    pid->d_term = pid->Kd * deriv;

    /* 合成 + 限幅 */
    pid->output = pid->p_term + pid->i_term + pid->d_term;
    if (pid->output > pid->output_max) pid->output = pid->output_max;
    if (pid->output < pid->output_min) pid->output = pid->output_min;

    pid->prev_error = e;
    return pid->output;
}

void PID_Reset(PID_t *pid)
{
    pid->error = pid->prev_error = 0.0f;
    pid->integral = 0.0f;
    pid->p_term = pid->i_term = pid->d_term = 0.0f;
    pid->output = 0.0f;
    pid->feedback = 0.0f;
}
