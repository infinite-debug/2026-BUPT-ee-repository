/**
 * cascade_pid.c — 串级 PID 实现
 *
 * 调用流程:
 *   巡线模式:  CascadePID_Update(cp, gray_error, actual_rpm, 0)
 *   转弯模式:  CascadePID_SetTarget(cp, rpm);
 *              CascadePID_Update(cp, 0, actual_rpm, 1);
 */

#include "cascade_pid.h"
#include "tuning_params.h"

void CascadePID_Init(CascadePID_t *cp,
    float outer_kp, float outer_kd, float outer_int_max,
    int16_t rpm_min, int16_t rpm_max,
    float inner_kp, float inner_ki, float inner_kd,
    int16_t inner_out_max, int16_t deadband)
{
    /* 外环: error→RPM, dt 由调用频率决定(=1 代表 1 个控制周期) */
    PID_Init(&cp->outer, outer_kp, 0.0f, outer_kd, outer_int_max,
             (float)rpm_max, -(float)rpm_max);

    /* 内环: RPM偏差→PWM */
    PID_Init(&cp->inner, inner_kp, inner_ki, inner_kd, inner_out_max,
             (float)inner_out_max, -(float)inner_out_max);

    cp->target_rpm = 0;
    cp->pwm        = 0;
    cp->rpm_min    = rpm_min;
    cp->rpm_max    = rpm_max;
    cp->deadband   = deadband;
}

int16_t CascadePID_Update(CascadePID_t *cp, float outer_error,
                          float actual_rpm, uint8_t bypass_outer)
{
    float rpm_target;

    if (!bypass_outer) {
        /* ── 外环: error → 目标 RPM ── */
        float rpm = PID_Update(&cp->outer, outer_error);
        if (rpm >  cp->rpm_max) rpm =  cp->rpm_max;
        if (rpm < -cp->rpm_max) rpm = -cp->rpm_max;

        /* 死区: 小值强制置零（车轮停止时的小漂移） */
        if (rpm > -cp->deadband && rpm < cp->deadband)
            rpm = 0;

        cp->target_rpm = (int16_t)rpm;
    }

    rpm_target = cp->target_rpm;

    /* ── 内环: RPM 偏差 → PWM ── */
    if (rpm_target == 0 && actual_rpm < PID_NEAR_ZERO_RPM && actual_rpm > -PID_NEAR_ZERO_RPM) {
        /* 目标=0 且几乎静止: 刹车，清零积分避免下次启动冲出去 */
        cp->pwm = 0;
        cp->inner.integral = 0;
    } else {
        float rpm_err = rpm_target - actual_rpm;
        cp->pwm = (int16_t)PID_Update(&cp->inner, rpm_err);
    }

    return cp->pwm;
}

void CascadePID_Reset(CascadePID_t *cp)
{
    PID_Reset(&cp->outer);
    PID_Reset(&cp->inner);
    cp->target_rpm = 0;
    cp->pwm = 0;
}
