/**
 * servo.h — SG90 舵机驱动（已废弃，保留空桩）
 */

#ifndef __SERVO_H
#define __SERVO_H

#include <ti/driverlib/driverlib.h>

static inline void Servo_Init(void) { }
static inline void Servo_SetAngle(uint8_t angle) { (void)angle; }

#endif
