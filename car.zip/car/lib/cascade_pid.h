/**
 * cascade_pid.h/c — 串级 PID（外环位置 + 内环速度）
 *
 * 外环: 位置/巡线 error → PID → 目标转速 (RPM)
 * 内环: 目标 RPM - 实际 RPM → PID → PWM 占空比
 *
 * 可复用: 同一套参数可用于巡线、原地旋转、直行。
 */

#ifndef __CASCADE_PID_H
#define __CASCADE_PID_H

#include "pid.h"
#include <stdint.h>

typedef struct {
    PID_t    outer;           /* 外环: error → target_rpm */
    PID_t    inner;           /* 内环: rpm_error → pwm */

    float    target_rpm;      /* 内环目标（外环输出或手动设定） */
    int16_t  pwm;             /* 最终 PWM 输出 */

    /* 外环限幅 */
    int16_t  rpm_min, rpm_max;

    /* 死区: |rpm| < deadband → 强制置零 */
    int16_t  deadband;
} CascadePID_t;

/**
 * 初始化
 * @param cp         句柄
 * @param outer_kp  外环 Kp（error → RPM 的比例）
 * @param outer_kd  外环 Kd（error 变化率的阻尼）
 * @param outer_int_max 外环积分限幅（通常 0 = 巡线不用 I）
 * @param rpm_min    外环输出最小值 (RPM)
 * @param rpm_max    外环输出最大值 (RPM)
 * @param inner_kp   内环 Kp（RPM 偏差 → PWM）
 * @param inner_ki   内环 Ki（消除速度稳态误差）
 * @param inner_kd   内环 Kd（抑制速度震荡）
 * @param inner_out_max 内环输出限幅 (±PWM_PERIOD)
 * @param deadband   死区 RPM（|target|<deadband → 输出 0）
 */
void CascadePID_Init(CascadePID_t *cp,
    float outer_kp, float outer_kd, float outer_int_max,
    int16_t rpm_min, int16_t rpm_max,
    float inner_kp, float inner_ki, float inner_kd,
    int16_t inner_out_max, int16_t deadband);

/**
 * 设定目标（手动模式）— 旁路外环，直接设内环目标
 * 用于转弯、直行等非巡线场景
 */
static inline void CascadePID_SetTarget(CascadePID_t *cp, int16_t rpm)
    { cp->target_rpm = rpm; }

/**
 * 一次控制迭代
 * @param cp           句柄
 * @param outer_error  外环误差（巡线 error ∈ [-1,+1]）
 * @param actual_rpm   当前实际转速（来自编码器）
 * @param bypass_outer 1=旁路外环(直接用 target_rpm), 0=正常串级
 * @return PWM 输出值
 */
int16_t CascadePID_Update(CascadePID_t *cp, float outer_error,
                          float actual_rpm, uint8_t bypass_outer);

/** 复位所有积分项 */
void CascadePID_Reset(CascadePID_t *cp);

#endif
