/**
 * system.h — 系统时钟初始化（MSPM0G3507）
 *
 * MSPM0G 的时钟系统:
 *   - SYSOSC = 32MHz 内部高速振荡器
 *   - SYSPLL 可升到 80MHz
 *   - MCLK = CPU, ULPCLK = 低速外设
 *
 * 供电模式: RUN0 (80MHz MCLK, 无 SYSPLL 时用 32MHz)
 */

#ifndef __SYSTEM_H
#define __SYSTEM_H

#include <ti/devices/msp/msp.h>
#include <ti/driverlib/driverlib.h>

static inline void System_ClockInit(void)
{
    /* 配置 SYSOSC 为 32MHz 基准 */
    DL_SYSCTL_setSYSOSCFreq(DL_SYSCTL_SYSOSC_FREQ_BASE);  // 32MHz

    /* 默认 MCLK = SYSOSC = 32MHz (不用 PLL 也够快) */
    DL_SYSCTL_setMCLKDivider(DL_SYSCTL_MCLK_DIVIDER_DISABLE);

    /* RUN0 模式: MCLK=SYSOSC, CPU 全速 */
    DL_SYSCTL_setPowerPolicyRUN0SLEEP0();
}

#endif
