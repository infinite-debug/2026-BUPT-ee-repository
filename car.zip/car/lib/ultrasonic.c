/**
 * ultrasonic.c — 超声波测距实现
 */

#include "ultrasonic.h"
#include "tuning_params.h"

static void ultrasonic_io_init(void)
{
    /* 初始化只做一次 */
    static int done = 0;
    if (done) return;
    done = 1;
    DL_GPIO_initDigitalOutput(ULTRASONIC_TRIG_IOMUX);
    DL_GPIO_initDigitalInput(ULTRASONIC_ECHO_IOMUX);
    DL_GPIO_clearPins(ULTRASONIC_PORT, ULTRASONIC_TRIG_PIN);
}

float Ultrasonic_Read(void)
{
    ultrasonic_io_init();

    /* Trig 发脉冲 */
    DL_GPIO_setPins(ULTRASONIC_PORT, ULTRASONIC_TRIG_PIN);
    delay_us(ULTRASONIC_TRIG_US);
    DL_GPIO_clearPins(ULTRASONIC_PORT, ULTRASONIC_TRIG_PIN);

    /* 等 Echo 变高 */
    uint32_t t0 = g_sys_ms;
    while (!DL_GPIO_readPins(ULTRASONIC_PORT, ULTRASONIC_ECHO_PIN)) {
        if ((g_sys_ms - t0) > ULTRASONIC_ECHO_TIMEOUT_MS) return -1.0f;
    }
    uint32_t t_start = g_sys_ms;

    /* 等 Echo 变低 */
    while (DL_GPIO_readPins(ULTRASONIC_PORT, ULTRASONIC_ECHO_PIN)) {
        if ((g_sys_ms - t_start) > ULTRASONIC_ECHO_LOW_TIMEOUT_MS) return -1.0f;
    }
    uint32_t t_end = g_sys_ms;

    uint32_t pulse_ms = t_end - t_start;
    return pulse_ms * ULTRASONIC_SPEED_FACTOR;
}
