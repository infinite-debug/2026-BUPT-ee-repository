/**
 * pid.h/c — 位置式 PID 控制器（平台无关，纯 C）
 *
 * MSPM0G3507 是 Cortex-M0+, 无硬件 FPU。
 * 浮点 PID 开销较大（约 30-50µs @ 32MHz），但 2ms 周期下可接受。
 */

#ifndef __PID_H
#define __PID_H

typedef struct {
    float Kp, Ki, Kd;
    float dt;
    float output_max, output_min;
    float integral_max, integral_min;
    float sep_threshold;
    float target, feedback, error;
    float p_term, i_term, d_term, output;
    float prev_error, integral;
} PID_t;

void  PID_Init(PID_t *pid, float Kp, float Ki, float Kd,
               float dt, float out_max, float out_min);
void  PID_SetTarget(PID_t *pid, float target);
void  PID_SetIntegralLimit(PID_t *pid, float max, float min);
void  PID_SetSepThreshold(PID_t *pid, float threshold);
float PID_Update(PID_t *pid, float feedback);
void  PID_Reset(PID_t *pid);

#endif
