/**
 * motion.c — 运动学实现
 *
 * 通过 CascadePID_SetTarget 设定左右轮目标 RPM，
 * 内环速度 PID 自动闭环追踪编码器反馈。
 */

#include "motion.h"
#include "motor.h"
#include "cascade_pid.h"

extern CascadePID_t g_cp_L;
extern CascadePID_t g_cp_R;

void Motion_Init(void)   { Motor_Init(); }
void Motion_Stop(void)   { CascadePID_Reset(&g_cp_L); CascadePID_Reset(&g_cp_R); }

void Motion_SetSpeed(float l_rpm, float r_rpm)
{
    CascadePID_SetTarget(&g_cp_L, (int16_t)l_rpm);
    CascadePID_SetTarget(&g_cp_R, (int16_t)r_rpm);
}

void Motion_Forward(float s)   { Motion_SetSpeed(s, s); }
void Motion_Backward(float s)  { Motion_SetSpeed(-s, -s); }
void Motion_TurnLeft(float s)  { Motion_SetSpeed(-s, s); }
void Motion_TurnRight(float s) { Motion_SetSpeed(s, -s); }
