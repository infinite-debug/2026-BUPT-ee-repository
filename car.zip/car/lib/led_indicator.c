#include "led_indicator.h"

static LEDPattern_t g_pattern = LED_ALL_OFF;
static uint8_t g_blink_tick = 0;

void LED_Init(void)
{
    DL_GPIO_initDigitalOutput(STATUS_LED_RED_IOMUX);
    DL_GPIO_initDigitalOutput(STATUS_LED_GREEN_IOMUX);
    DL_GPIO_initDigitalOutput(STATUS_LED_YELLOW_IOMUX);
    DL_GPIO_clearPins(STATUS_LED_PORT, STATUS_LED_RED_PIN);
    DL_GPIO_clearPins(STATUS_LED_PORT, STATUS_LED_GREEN_PIN);
    DL_GPIO_clearPins(STATUS_LED_PORT, STATUS_LED_YELLOW_PIN);
}

void LED_SetPattern(LEDPattern_t p)
{
    g_pattern = p;
    g_blink_tick = 0;
    LED_Update();
}

void LED_Update(void)
{
    g_blink_tick++;
    uint8_t r = 0, g = 0, y = 0;

    switch (g_pattern) {
    case LED_GREEN_SOLID:  g = 1; break;
    case LED_RED_SOLID:    r = 1; break;
    case LED_RED_BLINK:    r = (g_blink_tick & 2) ? 1 : 0; break;
    case LED_YELLOW_SOLID: y = 1; break;
    case LED_YELLOW_BLINK: y = (g_blink_tick & 2) ? 1 : 0; break;
    default: break;
    }

    if (r) DL_GPIO_setPins(STATUS_LED_PORT, STATUS_LED_RED_PIN);
    else   DL_GPIO_clearPins(STATUS_LED_PORT, STATUS_LED_RED_PIN);
    if (g) DL_GPIO_setPins(STATUS_LED_PORT, STATUS_LED_GREEN_PIN);
    else   DL_GPIO_clearPins(STATUS_LED_PORT, STATUS_LED_GREEN_PIN);
    if (y) DL_GPIO_setPins(STATUS_LED_PORT, STATUS_LED_YELLOW_PIN);
    else   DL_GPIO_clearPins(STATUS_LED_PORT, STATUS_LED_YELLOW_PIN);
}
