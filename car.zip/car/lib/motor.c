/**
 * motor.c — TB6612 标准 3 线模式（IN1 + IN2 + PWM）
 */

#include "motor.h"
#include "config.h"

static void motor_set_in(uint32_t in1, uint32_t in2,
                         uint32_t in1_val, uint32_t in2_val)
{
    if (in1_val)
        DL_GPIO_setPins(MOTOR_DIR_PORT, in1);
    else
        DL_GPIO_clearPins(MOTOR_DIR_PORT, in1);

    if (in2_val)
        DL_GPIO_setPins(MOTOR_DIR_PORT, in2);
    else
        DL_GPIO_clearPins(MOTOR_DIR_PORT, in2);
}

void Motor_Init(void)
{
    /* PA12 → TIMG0 CCP0, PA13 → TIMG0 CCP1 */
    DL_GPIO_initPeripheralOutputFunction(GPIO_MOTOR_C0_IOMUX,
        GPIO_MOTOR_C0_IOMUX_FUNC);
    DL_GPIO_initPeripheralOutputFunction(GPIO_MOTOR_C1_IOMUX,
        GPIO_MOTOR_C1_IOMUX_FUNC);

    /* IN1/IN2 方向引脚 */
    DL_GPIO_initDigitalOutput(MOTOR_DIR_L_IN1_IOMUX);
    DL_GPIO_initDigitalOutput(MOTOR_DIR_L_IN2_IOMUX);
    DL_GPIO_initDigitalOutput(MOTOR_DIR_R_IN1_IOMUX);
    DL_GPIO_initDigitalOutput(MOTOR_DIR_R_IN2_IOMUX);

    /* 全部 IN 拉低 = 滑行停止 */
    DL_GPIO_clearPins(MOTOR_DIR_PORT,
        MOTOR_DIR_L_IN1_PIN | MOTOR_DIR_L_IN2_PIN |
        MOTOR_DIR_R_IN1_PIN | MOTOR_DIR_R_IN2_PIN);

    DL_TimerG_enablePower(MOTOR_INST);

    DL_TimerG_ClockConfig clk_cfg = {
        .clockSel    = DL_TIMER_CLOCK_BUSCLK,
        .divideRatio = DL_TIMER_CLOCK_DIVIDE_1,
    };
    DL_TimerG_setClockConfig(MOTOR_INST, &clk_cfg);

    DL_Timer_PWMConfig pwm_cfg = {
        .period    = PWM_PERIOD,
        .pwmMode   = DL_TIMER_PWM_MODE_EDGE_ALIGN,
        .isTimerWithFourCC = false,
        .startTimer = DL_TIMER_START,
    };
    DL_TimerG_initPWMMode(MOTOR_INST, &pwm_cfg);

    /* 初始占空比=0 */
    DL_TimerG_setCaptureCompareValue(MOTOR_INST, 0, GPIO_MOTOR_C0_IDX);
    DL_Timer_setCaptureCompareOutCtl(MOTOR_INST, 0,
        DL_TIMER_CC_OCTL_INV_OUT_DISABLED,
        DL_TIMER_CC_OCTL_SRC_FUNCVAL,
        GPIO_MOTOR_C0_IDX);

    DL_TimerG_setCaptureCompareValue(MOTOR_INST, 0, GPIO_MOTOR_C1_IDX);
    DL_Timer_setCaptureCompareOutCtl(MOTOR_INST, 0,
        DL_TIMER_CC_OCTL_INV_OUT_DISABLED,
        DL_TIMER_CC_OCTL_SRC_FUNCVAL,
        GPIO_MOTOR_C1_IDX);
}

void Motor_Left(int16_t duty)
{
    if (duty > 0) {
        motor_set_in(MOTOR_DIR_L_IN1_PIN, MOTOR_DIR_L_IN2_PIN, 1, 0);
        DL_TimerG_setCaptureCompareValue(MOTOR_INST,
            (uint32_t)duty, GPIO_MOTOR_C0_IDX);
    } else if (duty < 0) {
        motor_set_in(MOTOR_DIR_L_IN1_PIN, MOTOR_DIR_L_IN2_PIN, 0, 1);
        DL_TimerG_setCaptureCompareValue(MOTOR_INST,
            (uint32_t)(-duty), GPIO_MOTOR_C0_IDX);
    } else {
        motor_set_in(MOTOR_DIR_L_IN1_PIN, MOTOR_DIR_L_IN2_PIN, 1, 1);
        DL_TimerG_setCaptureCompareValue(MOTOR_INST,
            0, GPIO_MOTOR_C0_IDX);
    }
}

void Motor_Right(int16_t duty)
{
    if (duty > 0) {
        motor_set_in(MOTOR_DIR_R_IN1_PIN, MOTOR_DIR_R_IN2_PIN, 1, 0);
        DL_TimerG_setCaptureCompareValue(MOTOR_INST,
            (uint32_t)duty, GPIO_MOTOR_C1_IDX);
    } else if (duty < 0) {
        motor_set_in(MOTOR_DIR_R_IN1_PIN, MOTOR_DIR_R_IN2_PIN, 0, 1);
        DL_TimerG_setCaptureCompareValue(MOTOR_INST,
            (uint32_t)(-duty), GPIO_MOTOR_C1_IDX);
    } else {
        motor_set_in(MOTOR_DIR_R_IN1_PIN, MOTOR_DIR_R_IN2_PIN, 1, 1);
        DL_TimerG_setCaptureCompareValue(MOTOR_INST,
            0, GPIO_MOTOR_C1_IDX);
    }
}

void Motor_Stop(void) { Motor_Left(0); Motor_Right(0); }
