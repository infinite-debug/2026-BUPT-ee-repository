/**
 * motion.h/c — 双轮差速运动学
 */

#ifndef __MOTION_H
#define __MOTION_H

#include "ti_msp_dl_config.h"

void Motion_Init(void);
void Motion_SetSpeed(float left_rpm, float right_rpm);
void Motion_Forward(float speed_rpm);
void Motion_Backward(float speed_rpm);
void Motion_TurnLeft(float speed_rpm);
void Motion_TurnRight(float speed_rpm);
void Motion_Stop(void);

#endif
