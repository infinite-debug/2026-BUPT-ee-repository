/**
 * ultrasonic.h/c — HC-SR04 超声波测距
 */

#ifndef __ULTRASONIC_H
#define __ULTRASONIC_H

#include "ti_msp_dl_config.h"
#include "delay.h"

float Ultrasonic_Read(void);

#endif
