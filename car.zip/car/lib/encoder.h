/**
 * encoder.h/c — 双编码器驱动（GPIO 中断计数）
 *
 * 左: PB20(A相) + PB13(B相)
 * 右: PB8(A相) + PB9(B相)
 * 同属 GPIOB，共用一个 GROUP1_IRQHandler
 */

#ifndef __ENCODER_H
#define __ENCODER_H

#include "ti_msp_dl_config.h"

typedef struct {
    volatile int32_t count;
    float rpm;
    int8_t dir;
    uint16_t sample_ms, cpr;
    int32_t last_count;

    /* 引脚信息，ISR 判向用 */
    GPIO_Regs *b_port;
    uint32_t   b_pin;
    uint32_t   a_pin;
} Encoder_t;

void Encoder_InitL(Encoder_t *enc, uint16_t ppr, uint16_t gear_ratio,
                   uint16_t sample_ms);
void Encoder_InitR(Encoder_t *enc, uint16_t ppr, uint16_t gear_ratio,
                   uint16_t sample_ms);
void Encoder_Update(Encoder_t *enc);
int32_t Encoder_GetCount(const Encoder_t *enc);
float   Encoder_GetRPM(const Encoder_t *enc);

#endif
