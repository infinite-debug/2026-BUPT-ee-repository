/**
 * uart.c — 调试串口实现（UART0, 115200）
 */

#include "uart.h"
#include "delay.h"
#include "tuning_params.h"
#include <stdio.h>
#include <string.h>

static volatile char   rx_buf[UART_DEBUG_BUF_SIZE];
static volatile uint8_t rx_head = 0;
static volatile uint8_t rx_tail = 0;
static volatile int    rx_line_ready = 0;

void UART_Init(void)
{
    DL_GPIO_initPeripheralOutputFunction(GPIO_DEBUG_IOMUX_TX,
        GPIO_DEBUG_IOMUX_TX_FUNC);
    DL_GPIO_initPeripheralInputFunction(GPIO_DEBUG_IOMUX_RX,
        GPIO_DEBUG_IOMUX_RX_FUNC);

    DL_UART_Main_enablePower(DEBUG_INST);

    DL_UART_Main_ClockConfig clk_cfg = {
        .clockSel    = DL_UART_MAIN_CLOCK_BUSCLK,
        .divideRatio = DL_UART_MAIN_CLOCK_DIVIDE_RATIO_1,
    };
    DL_UART_Main_setClockConfig(DEBUG_INST, &clk_cfg);

    DL_UART_Main_Config uart_cfg = {
        .mode        = DL_UART_MAIN_MODE_NORMAL,
        .direction   = DL_UART_MAIN_DIRECTION_TX_RX,
        .flowControl = DL_UART_MAIN_FLOW_CONTROL_NONE,
        .parity      = DL_UART_MAIN_PARITY_NONE,
        .wordLength  = DL_UART_MAIN_WORD_LENGTH_8_BITS,
        .stopBits    = DL_UART_MAIN_STOP_BITS_ONE,
    };
    DL_UART_Main_init(DEBUG_INST, &uart_cfg);

    DL_UART_Main_configBaudRate(DEBUG_INST, UART_BUS_CLK, UART_DEBUG_BAUD);

    DL_UART_Main_enableInterrupt(DEBUG_INST, DL_UART_MAIN_INTERRUPT_RX);
    NVIC_EnableIRQ(UART0_INT_IRQn);
}

void UART_SendByte(uint8_t ch)
    { DL_UART_Main_transmitDataBlocking(DEBUG_INST, ch); }

void UART_SendString(const char *str)
    { while (*str) UART_SendByte(*str++); }

void UART_Printf(const char *fmt, ...)
{
    char buf[UART_DEBUG_BUF_SIZE];
    va_list args;
    va_start(args, fmt);
    vsnprintf(buf, sizeof(buf), fmt, args);
    va_end(args);
    UART_SendString(buf);
}

int UART_ReadLine(char *buf, uint16_t maxlen)
{
    if (!rx_line_ready) return 0;
    uint16_t i = 0;
    __disable_irq();
    while (rx_head != rx_tail && i < maxlen - 1) {
        char c = rx_buf[rx_tail];
        rx_tail = (rx_tail + 1) % sizeof(rx_buf);
        if (c == '\r' || c == '\n') break;
        buf[i++] = c;
    }
    buf[i] = '\0';
    rx_line_ready = 0;
    __enable_irq();
    return 1;
}

void UART0_IRQHandler(void)
{
    if (DL_UART_Main_getPendingInterrupt(DEBUG_INST) &
        DL_UART_MAIN_IIDX_RX) {
        char c = DL_UART_Main_receiveData(DEBUG_INST);
        rx_buf[rx_head] = c;
        rx_head = (rx_head + 1) % sizeof(rx_buf);
        if (c == '\n') rx_line_ready = 1;
    }
}
