/**
 * speed_controller.c — 速度闭环 PID 实现
 *
 * PID 输入 = target_rpm - actual_rpm
 * PID 输出 = PWM 占空比（directly fed to Motor_Left/Right）
 *
 * Kp 把 RPM 偏差映射为 PWM 增量:
 *   例: Kp=20, 偏差=50RPM → 输出 += 1000 PWM ticks
 */

#include "speed_controller.h"
#include "tuning_params.h"

void SpeedController_Init(SpeedController_t *sc, float kp, float ki, float kd,
                          int16_t out_max)
{
    PID_Init(&sc->pid, kp, ki, kd, out_max, -out_max, out_max);
    sc->target_rpm = 0;
    sc->pwm_output = 0;
}

void SpeedController_Update(SpeedController_t *sc, float actual_rpm)
{
    float error = (float)sc->target_rpm - actual_rpm;

    /* 死区：目标=0 时不控速，直接输出 0（刹车） */
    if (sc->target_rpm == 0 && actual_rpm < PID_NEAR_ZERO_RPM && actual_rpm > -PID_NEAR_ZERO_RPM) {
        sc->pwm_output = 0;
        PID_Reset(&sc->pid);
        return;
    }

    float out = PID_Update(&sc->pid, error);
    sc->pwm_output = (int16_t)out;
}
