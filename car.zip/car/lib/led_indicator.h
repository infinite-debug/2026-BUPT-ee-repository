/**
 * led_indicator.h/c — 3 色 LED 状态指示
 *
 * 红=病房, 绿=药房, 黄=故障
 */

#ifndef __LED_INDICATOR_H
#define __LED_INDICATOR_H

#include "ti_msp_dl_config.h"

typedef enum {
    LED_ALL_OFF = 0,
    LED_GREEN_SOLID,
    LED_RED_SOLID,
    LED_RED_BLINK,
    LED_YELLOW_SOLID,
    LED_YELLOW_BLINK,
} LEDPattern_t;

void LED_Init(void);
void LED_SetPattern(LEDPattern_t p);
void LED_Update(void);

#endif
