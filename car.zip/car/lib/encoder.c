/**
 * encoder.c — 双编码器（GPIOB 中断, 左 PB20/PB13, 右 PB8/PB9）
 */

#include "encoder.h"
#include "config.h"
#include "tuning_params.h"
#include "ti_msp_dl_config.h"

static Encoder_t *g_enc_L = 0;
static Encoder_t *g_enc_R = 0;

static void encoder_init(Encoder_t *enc, uint16_t ppr, uint16_t gear_ratio,
                         uint16_t sample_ms,
                         GPIO_Regs *a_port, uint32_t a_pin, uint32_t a_iomux,
                         GPIO_Regs *b_port, uint32_t b_pin, uint32_t b_iomux)
{
    enc->count = enc->rpm = 0;
    enc->dir = 0;
    enc->sample_ms = sample_ms;
    enc->cpr = ppr * gear_ratio;
    enc->last_count = 0;
    enc->b_port = b_port;
    enc->b_pin  = b_pin;
    enc->a_pin  = a_pin;

    /* A 相: 输入 + 上拉 + 上升沿中断 */
    DL_GPIO_initDigitalInputFeatures(a_iomux,
        DL_GPIO_INVERSION_DISABLE, DL_GPIO_RESISTOR_PULL_UP,
        DL_GPIO_HYSTERESIS_DISABLE, DL_GPIO_WAKEUP_DISABLE);
    DL_GPIO_setUpperPinsPolarity(a_port, a_pin);
    DL_GPIO_clearInterruptStatus(a_port, a_pin);
    DL_GPIO_enableInterrupt(a_port, a_pin);

    /* B 相: 输入 + 上拉（只读电平） */
    DL_GPIO_initDigitalInputFeatures(b_iomux,
        DL_GPIO_INVERSION_DISABLE, DL_GPIO_RESISTOR_PULL_UP,
        DL_GPIO_HYSTERESIS_DISABLE, DL_GPIO_WAKEUP_DISABLE);

    /* GPIOB 中断统一入口 */
    NVIC_EnableIRQ(GPIOB_INT_IRQn);
}

void Encoder_InitL(Encoder_t *enc, uint16_t ppr, uint16_t gear_ratio,
                   uint16_t sample_ms)
{
    encoder_init(enc, ppr, gear_ratio, sample_ms,
        GPIOB, ENCODER_A_PIN, ENCODER_A_IOMUX,
        GPIOB, ENCODER_B_PIN, ENCODER_B_IOMUX);
    g_enc_L = enc;
}

void Encoder_InitR(Encoder_t *enc, uint16_t ppr, uint16_t gear_ratio,
                   uint16_t sample_ms)
{
    /* 右编码器: PB8(A 相) + PB9(B 相)
     * 注意: ENCODER_R GPIO 组名在 SysConfig 里是 "ENCODER_R" */
    encoder_init(enc, ppr, gear_ratio, sample_ms,
        GPIOB, ENCODER_R_RA_PIN, ENCODER_R_RA_IOMUX,
        GPIOB, ENCODER_R_RB_PIN, ENCODER_R_RB_IOMUX);
    g_enc_R = enc;
}

void Encoder_Update(Encoder_t *enc)
{
    int32_t delta = enc->count - enc->last_count;
    enc->last_count = enc->count;
    if (delta == 0) { enc->rpm = 0; enc->dir = 0; return; }
    enc->rpm = (delta * ENC_RPM_SCALE) / (enc->cpr * enc->sample_ms);
}

int32_t Encoder_GetCount(const Encoder_t *enc) { return enc->count; }
float   Encoder_GetRPM(const Encoder_t *enc)   { return enc->rpm; }

static void enc_isr_increment(Encoder_t *enc, GPIO_Regs *port, uint32_t a_pin)
{
    DL_GPIO_clearInterruptStatus(port, a_pin);
    if (enc) {
        if (DL_GPIO_readPins(enc->b_port, enc->b_pin))
            { enc->count++; enc->dir = 1; }
        else
            { enc->count--; enc->dir = -1; }
    }
}

void GROUP1_IRQHandler(void)
{
    uint32_t status = DL_GPIO_getEnabledInterruptStatus(GPIOB, ENCODER_A_PIN);
    if (status)
        enc_isr_increment(g_enc_L, GPIOB, ENCODER_A_PIN);

    status = DL_GPIO_getEnabledInterruptStatus(GPIOB, ENCODER_R_RA_PIN);
    if (status)
        enc_isr_increment(g_enc_R, GPIOB, ENCODER_R_RA_PIN);
}
