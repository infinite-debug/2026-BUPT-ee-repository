/**
 * speed_controller.h/c — 速度闭环 PID（内环）
 *
 * 每 2ms 调用一次，用编码器 RPM 反馈计算 PWM 输出。
 * 外环（巡线 PD）输出目标 RPM，内环用速度 PID 追踪目标转速。
 */

#ifndef __SPEED_CONTROLLER_H
#define __SPEED_CONTROLLER_H

#include "pid.h"
#include <stdint.h>

typedef struct {
    PID_t    pid;
    int16_t  target_rpm;       /* 目标转速（外环设定） */
    int16_t  pwm_output;       /* PID 计算出的 PWM */
} SpeedController_t;

void SpeedController_Init(SpeedController_t *sc, float kp, float ki, float kd,
                          int16_t out_max);
void SpeedController_Update(SpeedController_t *sc, float actual_rpm);

#endif
