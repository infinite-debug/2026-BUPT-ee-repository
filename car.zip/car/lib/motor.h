/**
 * motor.h/c — 直流电机 PWM 驱动（TB6612 标准 3 线模式）
 *
 * TB6612 每个通道:
 *   IN1  IN2  PWM   结果
 *    1    0    X    正转 (CW)
 *    0    1    X    反转 (CCW)
 *    1    1    X    短路刹车
 *    0    0    X    滑行/停止
 *
 * 引脚:
 *   左轮: PA12(PWM)  PA26(IN1)  PA24(IN2)
 *   右轮: PA13(PWM)  PA27(IN1)  PA25(IN2)
 */

#ifndef __MOTOR_H
#define __MOTOR_H

#include "ti_msp_dl_config.h"

void Motor_Init(void);
void Motor_Left(int16_t duty);
void Motor_Right(int16_t duty);
void Motor_Stop(void);

#endif
