/**
 * delay.h — 精准延时（Cortex-M0+, 无 DWT）
 *
 * MSPM0G3507 是 Cortex-M0+, 没有 DWT 周期计数器。
 * 用 SysTick 1ms 时基做毫秒延时，用 delay_cycles 做微秒延时。
 */

#ifndef __DELAY_H
#define __DELAY_H

#include <ti/driverlib/driverlib.h>

extern volatile uint32_t g_sys_ms;

void Delay_Init(void);
void delay_us(uint32_t us);
void delay_ms(uint32_t ms);

/** SysTick 1ms ISR — 在 main.c 中实现 */
void SysTick_Handler(void);

#endif
