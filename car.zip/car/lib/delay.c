/**
 * delay.c — SysTick 延时实现
 *
 * SysTick 配置为 1ms 周期（32MHz / 32000 = 1000Hz）
 * delay_us 使用 busyrun 循环 (delay_cycles)
 */

#include "delay.h"
#include "tuning_params.h"

volatile uint32_t g_sys_ms = 0;

void Delay_Init(void)
{
    DL_SYSTICK_init(SYSTICK_PERIOD);
    DL_SYSTICK_enableInterrupt();
    DL_SYSTICK_enable();
}

void SysTick_Handler(void)
{
    g_sys_ms++;
}

void delay_us(uint32_t us)
{
    /* 每个 cycle = 1/32MHz = 31.25ns, us * 32 = 所需 cycles */
    delay_cycles(us * CYCLES_PER_US);
}

void delay_ms(uint32_t ms)
{
    uint32_t start = g_sys_ms;
    while ((g_sys_ms - start) < ms);
}
