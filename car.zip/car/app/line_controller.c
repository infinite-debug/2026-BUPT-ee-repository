/**
 * line_controller.c — 灰度 PD 巡线（外环, 输出目标 RPM）
 */

#include "line_controller.h"
#include "../tuning_params.h"

void LineController_Init(LineController_t *lc, float Kp, float Kd,
                         int16_t base_rpm, int16_t max_corr)
{
    /* 巡线只用 PD, dt=0.002s (2ms 周期) */
    PID_Init(&lc->pid_line, Kp, 0.0f, Kd, 0.0f, (float)max_corr, -(float)max_corr);
    lc->base_rpm       = base_rpm;
    lc->max_correction = max_corr;
    lc->target_rpm_l = lc->target_rpm_r = 0;
    lc->last_valid_error = 0;
    lc->active = 0;
    lc->lost_phase = 0;
}

void LineController_Start(LineController_t *lc)
    { lc->active = 1; lc->lost_phase = 0; PID_Reset(&lc->pid_line); }
void LineController_Stop(LineController_t *lc)
    { lc->active = 0; lc->target_rpm_l = lc->target_rpm_r = 0; }
void LineController_GetTargetRPM(const LineController_t *lc,
                                 int16_t *left, int16_t *right)
    { *left = lc->target_rpm_l; *right = lc->target_rpm_r; }

void LineController_Update(LineController_t *lc, float error,
                           uint8_t lost, uint32_t lost_ms)
{
    if (!lc->active) return;
    float filtered = error;

    if (!lost) {
        lc->last_valid_error = error;
        lc->lost_phase = 0;
    } else {
        /* 丢线恢复策略 */
        if (lost_ms < LOST_PHASE1_MS)
            filtered = lc->last_valid_error;
        else if (lost_ms < LOST_PHASE2_MS)
            filtered = lc->last_valid_error + LOST_PHASE2_OFFSET;
        else if (lost_ms < LOST_PHASE3_MS)
            filtered = lc->last_valid_error + LOST_PHASE3_OFFSET;
        else if (lost_ms < LOST_PHASE4_MS)
            filtered = lc->last_valid_error
                + ((lost_ms / LOST_PHASE4_PERIOD) % 2 == 0
                    ? LOST_PHASE4_AMP : -LOST_PHASE4_AMP);
        else { lc->target_rpm_l = lc->target_rpm_r = 0; return; }
    }

    float corr = PID_Update(&lc->pid_line, filtered);

    /* corr>0 = 线偏右 → 左轮加速,右轮减速 → 车左转回线 */
    int16_t l_rpm = lc->base_rpm + (int16_t)corr;
    int16_t r_rpm = lc->base_rpm - (int16_t)corr;

    /* 下限保底: 转速太低电机堵转 */
    if (l_rpm < LINE_RPM_MIN_ABS && l_rpm > -LINE_RPM_MIN_ABS)
        l_rpm = (l_rpm >= 0) ? LINE_RPM_MIN_ABS : -LINE_RPM_MIN_ABS;
    if (r_rpm < LINE_RPM_MIN_ABS && r_rpm > -LINE_RPM_MIN_ABS)
        r_rpm = (r_rpm >= 0) ? LINE_RPM_MIN_ABS : -LINE_RPM_MIN_ABS;
    if (l_rpm >  LINE_RPM_MAX) l_rpm =  LINE_RPM_MAX;
    if (l_rpm < -LINE_RPM_MAX) l_rpm = -LINE_RPM_MAX;
    if (r_rpm >  LINE_RPM_MAX) r_rpm =  LINE_RPM_MAX;
    if (r_rpm < -LINE_RPM_MAX) r_rpm = -LINE_RPM_MAX;

    lc->target_rpm_l = l_rpm;
    lc->target_rpm_r = r_rpm;
}
