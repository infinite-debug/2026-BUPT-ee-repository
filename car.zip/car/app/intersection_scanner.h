/**
 * intersection_scanner.h/c — 路口动态扫描
 */

#ifndef __INTERSECTION_SCANNER_H
#define __INTERSECTION_SCANNER_H

#include "../lib/motion.h"
#include "uart_protocol.h"
#include "../tuning_params.h"
#include <stdint.h>

typedef struct {
    uint8_t left_wards[SCAN_MAX_WARDS_PER_SIDE];
    uint8_t left_count;
    uint8_t right_wards[SCAN_MAX_WARDS_PER_SIDE];
    uint8_t right_count;
    uint8_t  phase;
    uint8_t  done;
    uint32_t phase_start;
    UARTProtocol_t *uart;
} IntersectionScanner_t;

void IntersectionScanner_Init(IntersectionScanner_t *s, UARTProtocol_t *u);
void IntersectionScanner_Start(IntersectionScanner_t *s);
uint8_t IntersectionScanner_Update(IntersectionScanner_t *s, uint32_t now);
char IntersectionScanner_FindWard(const IntersectionScanner_t *s, uint8_t tgt);
void IntersectionScanner_Reset(IntersectionScanner_t *s);

#endif
