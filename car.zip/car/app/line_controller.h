/**
 * line_controller.h/c — PD 巡线控制器（外环）
 *
 * 输入灰度 error，输出左右轮目标 RPM（由内环速度 PID 追踪）
 */

#ifndef __LINE_CONTROLLER_H
#define __LINE_CONTROLLER_H

#include "ti_msp_dl_config.h"
#include "../lib/pid.h"
#include <stdint.h>

typedef struct {
    PID_t   pid_line;
    int16_t base_rpm;          /* 基础 RPM */
    int16_t max_correction;    /* 差速修正上限 (RPM) */
    int16_t target_rpm_l;      /* 输出: 左轮目标 RPM */
    int16_t target_rpm_r;      /* 输出: 右轮目标 RPM */
    float   last_valid_error;
    uint8_t active;
    uint8_t lost_phase;
} LineController_t;

void LineController_Init(LineController_t *lc, float Kp, float Kd,
                         int16_t base_rpm, int16_t max_corr);
void LineController_Update(LineController_t *lc, float error,
                           uint8_t lost, uint32_t lost_ms);
void LineController_Start(LineController_t *lc);
void LineController_Stop(LineController_t *lc);
void LineController_GetTargetRPM(const LineController_t *lc,
                                 int16_t *left, int16_t *right);

#endif
