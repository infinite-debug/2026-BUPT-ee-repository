/**
 * delivery_fsm.c — 状态机实现（平台无关）
 */

#include "delivery_fsm.h"
#include "path_planner.h"
#include "../lib/motion.h"
#include "../lib/servo.h"
#include "../lib/uart.h"
#include "../lib/cascade_pid.h"
#include "../tuning_params.h"
#include <stdio.h>
#include <string.h>

extern uint8_t        g_line_active;
extern CascadePID_t   g_cp_L, g_cp_R;

#define ELAPSED(fsm)  ((fsm)->now_ms - (fsm)->state_start_ms)
#define SET_STATE(fsm, s) do { \
    (fsm)->state = (s); \
    (fsm)->state_start_ms = (fsm)->now_ms; \
} while(0)

void DeliveryFSM_Init(DeliveryFSM_t *fsm,
    UARTProtocol_t *uart, IntersectionScanner_t *scanner)
{
    memset(fsm, 0, sizeof(*fsm));
    fsm->state = FSM_IDLE;
    fsm->uart = uart; fsm->scanner = scanner;
}

void DeliveryFSM_StartMission(DeliveryFSM_t *fsm, uint8_t ward)
{
    if (!PathPlanner_IsValidWard(ward)) return;
    fsm->target_ward = ward;
    fsm->intersections_passed = 0;
    fsm->scan_result = '0';
    fsm->mission_start_ms = fsm->now_ms;
    fsm->unload_confirmed = 0;
    LED_SetPattern(LED_ALL_OFF);
    SET_STATE(fsm, FSM_LOAD_DETECT);
}

void DeliveryFSM_EmergencyStop(DeliveryFSM_t *fsm)
{
    Motion_Stop();
    g_line_active = 0;
    SET_STATE(fsm, FSM_IDLE);
    LED_SetPattern(LED_ALL_OFF);
}

void DeliveryFSM_ConfirmUnload(DeliveryFSM_t *fsm)
    { fsm->unload_confirmed = 1; }

void DeliveryFSM_PrintStatus(const DeliveryFSM_t *fsm)
{
    const char *names[] = {
        "IDLE","LOAD","LFOUT","AT_INT","SCAN",
        "TURN_W","TURN_BR","FOLLOW_B","SCAN_BR",
        "APPR","STOP","WAIT","EXIT","TO_MAIN","TURN_HM","LFBACK",
        "PHARM","DONE","ERR"};
    int idx = (fsm->state <= FSM_ERROR) ? fsm->state : FSM_ERROR;
    UART_Printf("[FSM] %s ward=%d int=%d "
               "scan=%c elapsed=%lums\r\n",
               names[idx], fsm->target_ward,
               fsm->intersections_passed, fsm->scan_result,
               fsm->now_ms - fsm->mission_start_ms);
}

void DeliveryFSM_Update(DeliveryFSM_t *fsm, uint32_t now_ms)
{
    fsm->now_ms = now_ms;

    /* 任务总超时 */
    if (fsm->state > FSM_IDLE && fsm->state < FSM_DONE) {
        if (now_ms - fsm->mission_start_ms > FSM_T_MISSION_MAX) {
            Motion_Stop(); g_line_active = 0;
            LED_SetPattern(LED_YELLOW_SOLID);
            SET_STATE(fsm, FSM_ERROR);
        }
    }

    switch (fsm->state) {

    case FSM_IDLE:
        break;

    case FSM_LOAD_DETECT:
        if (ELAPSED(fsm) > FSM_T_LOAD_DETECT) {
            g_line_active = 1;
            CascadePID_Reset(&g_cp_L); CascadePID_Reset(&g_cp_R);
            LED_SetPattern(LED_ALL_OFF);
            SET_STATE(fsm, FSM_LINE_FOLLOW_OUT);
        }
        break;

    case FSM_LINE_FOLLOW_OUT:
        if (Track_IsLineLost() &&
            Track_GetLostDuration(now_ms) > FSM_T_LOST_THRESHOLD_MS) {
            SET_STATE(fsm, FSM_ERROR);
            LED_SetPattern(LED_YELLOW_SOLID);
            break;
        }
        if (Track_DetectIntersection()) {
            fsm->intersections_passed++;
            uint8_t min = PathPlanner_MinIntersections(fsm->target_ward);
            if (fsm->intersections_passed > min) {
                g_line_active = 0;
                Motion_Stop();
                SET_STATE(fsm, FSM_AT_INTERSECTION);
            }
        }
        break;

    case FSM_AT_INTERSECTION:
        if (ELAPSED(fsm) > FSM_T_AT_INTER_HOLD) {
            if (fsm->target_ward <= PATH_NEAR_WARD_MAX) {
                /* 1、2号房固定位置，不需 OpenMV 扫描 */
                fsm->scan_result = (fsm->target_ward == 1) ? 'L' : 'R';
                SET_STATE(fsm, FSM_TURN_INTO_WARD);
            } else {
                /* 3-8号房需要 OpenMV 扫描识别 */
                IntersectionScanner_Start(fsm->scanner);
                SET_STATE(fsm, FSM_SCAN_INTERSECTION);
            }
        }
        break;

    case FSM_SCAN_INTERSECTION:
        if (!IntersectionScanner_Update(fsm->scanner, now_ms))
            break;
        fsm->scan_result = IntersectionScanner_FindWard(
            fsm->scanner, fsm->target_ward);
        if (fsm->scan_result == '0') {
            ; g_line_active = 1; CascadePID_Reset(&g_cp_L); CascadePID_Reset(&g_cp_R);
            SET_STATE(fsm, FSM_LINE_FOLLOW_OUT);
        } else if (PathPlanner_IsBranchNode(fsm->target_ward)
                   && fsm->intersections_passed >= PATH_BRANCH_MIN_INTERS) {
            SET_STATE(fsm, FSM_TURN_BRANCH);
        } else {
            SET_STATE(fsm, FSM_TURN_INTO_WARD);
        }
        break;

    case FSM_TURN_INTO_WARD:
        if (ELAPSED(fsm) < FSM_T_INIT_ACTION_MS) {
            if (fsm->scan_result == 'L')
                Motion_TurnLeft(FSM_SPEED_TURN);
            else
                Motion_TurnRight(FSM_SPEED_TURN);
        }
        if (ELAPSED(fsm) > FSM_TURN_DURATION_MS) {
            Motion_Stop();
            SET_STATE(fsm, FSM_APPROACH_WARD);
        }
        break;

    case FSM_TURN_BRANCH:
        if (ELAPSED(fsm) < FSM_T_INIT_ACTION_MS)
            Motion_TurnLeft(fsm->scan_result == 'L' ? FSM_SPEED_TURN : -FSM_SPEED_TURN);
        if (ELAPSED(fsm) > FSM_TURN_DURATION_MS) {
            Motion_Stop();
            ; g_line_active = 1; CascadePID_Reset(&g_cp_L); CascadePID_Reset(&g_cp_R);
            SET_STATE(fsm, FSM_FOLLOW_BRANCH);
        }
        break;

    case FSM_FOLLOW_BRANCH:
        if (Track_DetectIntersection()) {
            g_line_active = 0;
            Motion_Stop();
            IntersectionScanner_Start(fsm->scanner);
            SET_STATE(fsm, FSM_SCAN_ON_BRANCH);
        }
        break;

    case FSM_SCAN_ON_BRANCH:
        if (!IntersectionScanner_Update(fsm->scanner, now_ms))
            break;
        fsm->scan_result = IntersectionScanner_FindWard(
            fsm->scanner, fsm->target_ward);
        SET_STATE(fsm, fsm->scan_result != '0'
            ? FSM_TURN_INTO_WARD : FSM_LINE_FOLLOW_OUT);
        break;

    case FSM_APPROACH_WARD:
        if (ELAPSED(fsm) < FSM_T_INIT_ACTION_MS) Motion_Forward(FSM_SPEED_APPROACH);
        if (ELAPSED(fsm) > FSM_T_APPROACH_MS) {
            Motion_Stop();
            LED_SetPattern(LED_RED_SOLID);
            SET_STATE(fsm, FSM_STOP_AT_WARD);
        }
        break;

    case FSM_STOP_AT_WARD:
        if (ELAPSED(fsm) > FSM_T_STOP_WARD) {
            LED_SetPattern(LED_RED_BLINK);
            SET_STATE(fsm, FSM_WAIT_UNLOAD);
        }
        break;

    case FSM_WAIT_UNLOAD:
        if (fsm->unload_confirmed ||
            DL_GPIO_readPins(BUTTON_UNLOAD_PORT, BUTTON_UNLOAD_PIN)) {
            LED_SetPattern(LED_ALL_OFF);
            SET_STATE(fsm, FSM_EXIT_WARD);
        }
        if (ELAPSED(fsm) > FSM_T_WAIT_UNLOAD)
            SET_STATE(fsm, FSM_EXIT_WARD);
        break;

    case FSM_EXIT_WARD:
        /* 第 1 步：180° 掉头（病房内） */
        if (ELAPSED(fsm) < FSM_T_INIT_ACTION_MS) Motion_TurnRight(FSM_SPEED_TURN);
        if (ELAPSED(fsm) > FSM_T_EXIT_ROTATE) {
            Motion_Forward(FSM_SPEED_EXIT);                           // 直走出走廊
            SET_STATE(fsm, FSM_EXIT_TO_MAIN);
        }
        break;

    case FSM_EXIT_TO_MAIN:
        /* 第 2 步：直走直到检测到主路路口 */
        if (Track_DetectIntersection()) {
            Motion_Stop();
            /* 病房在左边 → 返航右转；病房在右边 → 返航左转 */
            if (fsm->scan_result == 'L')
                Motion_TurnRight(FSM_SPEED_TURN);
            else
                Motion_TurnLeft(FSM_SPEED_TURN);
            SET_STATE(fsm, FSM_EXIT_TURN_HOME);
        }
        break;

    case FSM_EXIT_TURN_HOME:
        /* 第 3 步：转约 90° 进入主路（朝药房方向） */
        if (ELAPSED(fsm) > FSM_RETURN_TURN_DUR_MS) {
            Motion_Stop();
            ; g_line_active = 1; CascadePID_Reset(&g_cp_L); CascadePID_Reset(&g_cp_R);
            SET_STATE(fsm, FSM_LINE_FOLLOW_BACK);
        }
        break;

    case FSM_LINE_FOLLOW_BACK:
        if (Track_DetectIntersection()) {
            /* 每过一个路口减 1，减到 0 = 回到药房 */
            if (fsm->intersections_passed > 0)
                fsm->intersections_passed--;
            if (fsm->intersections_passed == 0) {
                g_line_active = 0;
                Motion_Stop();
                LED_SetPattern(LED_GREEN_SOLID);
                SET_STATE(fsm, FSM_STOP_AT_PHARMACY);
            }
        }
        break;

    case FSM_STOP_AT_PHARMACY:
        if (ELAPSED(fsm) > FSM_T_PHARMACY_HOLD)
            SET_STATE(fsm, FSM_DONE);
        break;

    case FSM_DONE:
        if (ELAPSED(fsm) < FSM_T_INIT_ACTION_MS) {
            UARTProtocol_SendDone();
            UART_Printf("[FSM] Mission complete!\r\n");
        }
        break;

    case FSM_ERROR:
        break;
    }
}
