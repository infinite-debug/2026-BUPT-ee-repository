#include "intersection_scanner.h"
#include "../tuning_params.h"
#include <string.h>

enum { PH_ROTATE_LEFT=1, PH_READ_LEFT, PH_ROTATE_RIGHT,
       PH_READ_RIGHT, PH_RETURN, PH_DONE };

void IntersectionScanner_Init(IntersectionScanner_t *s, UARTProtocol_t *u)
{
    memset(s, 0, sizeof(*s));
    s->uart = u;
}

void IntersectionScanner_Start(IntersectionScanner_t *s)
{
    s->phase = PH_ROTATE_LEFT;
    s->done = 0;
    s->left_count = s->right_count = 0;
    while (UARTProtocol_HasNewWard(s->uart))
        UARTProtocol_GetWard(s->uart);
    UARTProtocol_SendScanReq();
}

void IntersectionScanner_Reset(IntersectionScanner_t *s)
    { s->phase = 0; s->done = 0; s->left_count = s->right_count = 0; }

char IntersectionScanner_FindWard(const IntersectionScanner_t *s, uint8_t tgt)
{
    for (int i = 0; i < s->left_count; i++)
        if (s->left_wards[i] == tgt) return 'L';
    for (int i = 0; i < s->right_count; i++)
        if (s->right_wards[i] == tgt) return 'R';
    return '0';
}

uint8_t IntersectionScanner_Update(IntersectionScanner_t *s, uint32_t now)
{
    switch (s->phase) {
    case PH_ROTATE_LEFT:
        Motion_TurnLeft(SCAN_ROTATE_SPEED);
        if (now - s->phase_start > SCAN_LEFT_DURATION_MS) {
            Motion_Stop();
            s->phase_start = now;
            s->phase = PH_READ_LEFT;
        }
        break;
    case PH_READ_LEFT:
        while (UARTProtocol_HasNewWard(s->uart)) {
            uint8_t w = UARTProtocol_GetWard(s->uart);
            if (w && s->left_count < SCAN_MAX_WARDS_PER_SIDE)
                s->left_wards[s->left_count++] = w;
        }
        if (now - s->phase_start > SCAN_READ_DURATION_MS) {
            s->phase_start = now;
            s->phase = PH_ROTATE_RIGHT;
        }
        break;
    case PH_ROTATE_RIGHT:
        Motion_TurnRight(SCAN_ROTATE_SPEED);
        if (now - s->phase_start > SCAN_RIGHT_DURATION_MS) {
            Motion_Stop();
            s->phase_start = now;
            s->phase = PH_READ_RIGHT;
        }
        break;
    case PH_READ_RIGHT:
        while (UARTProtocol_HasNewWard(s->uart)) {
            uint8_t w = UARTProtocol_GetWard(s->uart);
            if (w && s->right_count < SCAN_MAX_WARDS_PER_SIDE)
                s->right_wards[s->right_count++] = w;
        }
        if (now - s->phase_start > SCAN_READ_DURATION_MS) {
            s->phase_start = now;
            s->phase = PH_RETURN;
        }
        break;
    case PH_RETURN:
        Motion_TurnLeft(SCAN_ROTATE_SPEED);
        if (now - s->phase_start > SCAN_RETURN_DURATION_MS) {
            Motion_Stop();
            s->phase = PH_DONE;
        }
        break;
    case PH_DONE:
        s->done = 1;
        return 1;
    }
    return 0;
}
