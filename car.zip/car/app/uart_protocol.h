/**
 * uart_protocol.h/c — OpenMV 通信协议（UART2, 9600bps）
 *
 * 协议: "WARD:N\n" → 识别到病房号
 *       "ACK:N\n" → 确认收到
 *       "SCAN\n"  → 请求识别
 *       "DONE\n"  → 任务完成
 */

#ifndef __UART_PROTOCOL_H
#define __UART_PROTOCOL_H

#include "ti_msp_dl_config.h"
#include "../tuning_params.h"
#include <stdint.h>

typedef struct {
    uint8_t rx_buf[UART_RX_BUF_SIZE];
    uint8_t rx_idx;
    uint8_t ward_received;
    uint8_t ward_number;
    uint8_t new_data;
} UARTProtocol_t;

void UARTProtocol_Init(UARTProtocol_t *p);
void UARTProtocol_FeedByte(UARTProtocol_t *p, uint8_t ch);
uint8_t UARTProtocol_HasNewWard(UARTProtocol_t *p);
uint8_t UARTProtocol_GetWard(UARTProtocol_t *p);
void UARTProtocol_SendAck(uint8_t ward);
void UARTProtocol_SendScanReq(void);
void UARTProtocol_SendDone(void);

/* ISR 回调 */
void VISION_UART_ISR(UARTProtocol_t *p);

#endif
