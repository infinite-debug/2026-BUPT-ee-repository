/**
 * path_planner.h/c — 路径规划辅助（平台无关）
 */

#ifndef __PATH_PLANNER_H
#define __PATH_PLANNER_H
#include <stdint.h>

uint8_t PathPlanner_IsValidWard(uint8_t ward);
uint8_t PathPlanner_MinIntersections(uint8_t ward);
uint8_t PathPlanner_IsBranchNode(uint8_t ward);

#endif
