/**
 * path_planner.c — 赛道布局辅助
 *
 * 物理布局（2021 F 题）：
 *   药房 → 路口1 → [1号房(左) / 2号房(右)]           ← 近端，固定位置，不需要 OpenMV
 *        → 路口2 → [3-4号房随机其中2个]               ← 中端，需要 OpenMV 扫描
 *        → 路口3(Y分叉) → 分支走廊 → [5-8号房剩余4个] ← 远端，需要先拐进分支再扫
 *
 *   MinIntersections: 到达目标区域前最少跳过的路口数
 *   IsBranchNode:     是否需要先拐进 Y 分叉走廊
 */

#include "path_planner.h"
#include "../tuning_params.h"

uint8_t PathPlanner_IsValidWard(uint8_t ward)
    { return (ward >= WARD_NUMBER_MIN && ward <= WARD_NUMBER_MAX); }

uint8_t PathPlanner_MinIntersections(uint8_t ward)
    { return (ward <= PATH_NEAR_WARD_MAX) ? 0 : 1; }
/* 1-2号: 路口1直接就是目标 → 跳过0个路口
 * 3-8号: 路口1是近端，路口2开始才可能有目标 → 跳过1个路口 */

uint8_t PathPlanner_IsBranchNode(uint8_t ward)
    { return (ward >= PATH_BRANCH_WARD_MIN); }
/* 5-8号: 在路口3的Y分叉远端 → 需要先进分支走廊再扫描 */
