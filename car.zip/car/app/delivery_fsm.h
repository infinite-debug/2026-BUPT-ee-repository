/**
 * delivery_fsm.h/c — 送药小车主状态机（平台无关）
 */

#ifndef __DELIVERY_FSM_H
#define __DELIVERY_FSM_H

#include "ti_msp_dl_config.h"
#include "../lib/led_indicator.h"
#include "uart_protocol.h"
#include "intersection_scanner.h"
#include "track.h"
#include <stdint.h>

typedef enum {
    FSM_IDLE = 0,
    FSM_LOAD_DETECT,
    FSM_LINE_FOLLOW_OUT,
    FSM_AT_INTERSECTION,
    FSM_SCAN_INTERSECTION,
    FSM_TURN_INTO_WARD,
    FSM_TURN_BRANCH,
    FSM_FOLLOW_BRANCH,
    FSM_SCAN_ON_BRANCH,
    FSM_APPROACH_WARD,
    FSM_STOP_AT_WARD,
    FSM_WAIT_UNLOAD,
    FSM_EXIT_WARD,
    FSM_EXIT_TO_MAIN,
    FSM_EXIT_TURN_HOME,
    FSM_LINE_FOLLOW_BACK,
    FSM_STOP_AT_PHARMACY,
    FSM_DONE,
    FSM_ERROR
} FSMState_t;

typedef struct {
    FSMState_t state;
    uint8_t    target_ward;
    uint8_t    intersections_passed;
    char       scan_result;
    UARTProtocol_t      *uart;
    IntersectionScanner_t *scanner;
    uint32_t   state_start_ms;
    uint32_t   mission_start_ms;
    uint32_t   now_ms;
    uint8_t    unload_confirmed;
} DeliveryFSM_t;

void DeliveryFSM_Init(DeliveryFSM_t *fsm,
    UARTProtocol_t *uart, IntersectionScanner_t *scanner);
void DeliveryFSM_StartMission(DeliveryFSM_t *fsm, uint8_t ward);
void DeliveryFSM_Update(DeliveryFSM_t *fsm, uint32_t now_ms);
void DeliveryFSM_EmergencyStop(DeliveryFSM_t *fsm);
void DeliveryFSM_ConfirmUnload(DeliveryFSM_t *fsm);
void DeliveryFSM_PrintStatus(const DeliveryFSM_t *fsm);

#endif
