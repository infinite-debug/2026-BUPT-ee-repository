/**
 * uart_protocol.c — OpenMV 通信（UART2, 9600bps）
 */

#include "uart_protocol.h"
#include "../tuning_params.h"
#include <string.h>
#include <stdio.h>

static void parse_frame(UARTProtocol_t *p)
{
    int ward;
    if (sscanf((char*)p->rx_buf, "WARD:%d", &ward) == 1) {
        if (ward >= WARD_NUMBER_MIN && ward <= WARD_NUMBER_MAX) {
            p->ward_number = ward;
            p->ward_received = 1;
            p->new_data = 1;
            UARTProtocol_SendAck(ward);
        }
    }
}

void UARTProtocol_Init(UARTProtocol_t *p)
{
    memset(p, 0, sizeof(UARTProtocol_t));

    DL_GPIO_initPeripheralOutputFunction(GPIO_VISION_IOMUX_TX,
        GPIO_VISION_IOMUX_TX_FUNC);
    DL_GPIO_initPeripheralInputFunction(GPIO_VISION_IOMUX_RX,
        GPIO_VISION_IOMUX_RX_FUNC);

    DL_UART_Main_enablePower(VISION_INST);

    DL_UART_Main_ClockConfig clk = {
        .clockSel    = DL_UART_MAIN_CLOCK_BUSCLK,
        .divideRatio = DL_UART_MAIN_CLOCK_DIVIDE_RATIO_1,
    };
    DL_UART_Main_setClockConfig(VISION_INST, &clk);

    DL_UART_Main_Config cfg = {
        .mode        = DL_UART_MAIN_MODE_NORMAL,
        .direction   = DL_UART_MAIN_DIRECTION_TX_RX,
        .flowControl = DL_UART_MAIN_FLOW_CONTROL_NONE,
        .parity      = DL_UART_MAIN_PARITY_NONE,
        .wordLength  = DL_UART_MAIN_WORD_LENGTH_8_BITS,
        .stopBits    = DL_UART_MAIN_STOP_BITS_ONE,
    };
    DL_UART_Main_init(VISION_INST, &cfg);
    DL_UART_Main_configBaudRate(VISION_INST, UART_BUS_CLK, UART_VISION_BAUD);

    DL_UART_Main_enableInterrupt(VISION_INST, DL_UART_MAIN_INTERRUPT_RX);
    NVIC_EnableIRQ(UART2_INT_IRQn);
}

void UARTProtocol_FeedByte(UARTProtocol_t *p, uint8_t ch)
{
    if (ch == '\n' || ch == '\r') {
        if (p->rx_idx > 0) {
            p->rx_buf[p->rx_idx] = '\0';
            parse_frame(p);
        }
        p->rx_idx = 0;
    } else {
        if (p->rx_idx < sizeof(p->rx_buf) - 1)
            p->rx_buf[p->rx_idx++] = ch;
        else
            p->rx_idx = 0;
    }
}

uint8_t UARTProtocol_HasNewWard(UARTProtocol_t *p) { return p->new_data; }
uint8_t UARTProtocol_GetWard(UARTProtocol_t *p)
    { p->new_data = 0; return p->ward_number; }

static void send_str(const char *s)
    { while (*s) DL_UART_Main_transmitDataBlocking(VISION_INST, *s++); }

void UARTProtocol_SendAck(uint8_t w)
    { char b[16]; snprintf(b, 16, "ACK:%d\r\n", w); send_str(b); }
void UARTProtocol_SendScanReq(void) { send_str("SCAN\r\n"); }
void UARTProtocol_SendDone(void)    { send_str("DONE\r\n"); }

void VISION_UART_ISR(UARTProtocol_t *p)
{
    if (DL_UART_Main_getPendingInterrupt(VISION_INST) &
        DL_UART_MAIN_IIDX_RX)
        UARTProtocol_FeedByte(p, DL_UART_Main_receiveData(VISION_INST));
}

void UART2_IRQHandler(void)
{
    extern UARTProtocol_t g_uart_proto;
    VISION_UART_ISR(&g_uart_proto);
}
