# MSPM0G3507 八路无编码器循迹

这版只包含：

- 八路灰度传感器（CD4051轮询 X1～X8）
- TB6612 双电机控制
- 八路 PD 循迹
- 白布丢线和悬空保护

不包含 `encoder.c/.h` 和 `speed_control.c/.h`。

## 关键状态

程序中的位顺序为 `bit0...bit7 = X1...X8`，`1` 表示检测到黑线或低反射：

| 结果 | 含义 | 动作 |
|---|---|---|
| `00000000` | 八路都在白布上，没有黑线 | 立即停车 |
| `00011000` | X4、X5在黑线上 | 左右轮等速直行 |
| `11111111` | 八路都无反射，常见于悬空 | 立即停车 |
| 其他连续黑线组合 | 黑线偏左或偏右 | PD转向 |
| 不连续的多个黑色区域 | 噪声或探头异常 | 立即停车 |

数字灰度传感器无法从单个探头的电平上区分“黑线”和“悬空”，
所以程序利用八路图案区分：赛道直行只应是中间 X4、X5，悬空通常是八路全部低反射。

## 放入 CCS 工程

1. 使用本目录中的 `main.c`、`grey.c/.h`、`track.c/.h`、
   `motor.c/.h` 和 `car_config.h`。
2. 删除或排除 `encoder.c/.h`、`speed_control.c/.h`。
3. 确保本目录的 `main.c` 参与编译，并排除旧的 `empty.c` 主函数。
4. 执行 `Clean -> Build Project -> 重新烧录`。

SysConfig 不需要新增编码器引脚。原有 PWM、电机和灰度引脚保持不变。

## 白布电平检查

默认：

```c
#define GREY_WHITE_LEVEL 1U
```

在 CCS Expressions 中观察：

```c
g_grey_raw_pattern
g_grey_line_pattern
g_track_state
```

全放在白布上时，`g_grey_line_pattern` 应为 `0x00`。
如果此时为 `0xFF`，把 `GREY_WHITE_LEVEL` 改为 `0U`。

`g_track_state`：

- `0`：白布丢线
- `1`：有效黑线
- `2`：八路全低反射（悬空/全黑）
- `3`：不连续或对称宽黑区等无效图案
