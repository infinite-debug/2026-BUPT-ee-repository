#ifndef TRACK_H_
#define TRACK_H_

#include <stdbool.h>
#include <stdint.h>

typedef enum {
    TRACK_STATE_WHITE_LOST = 0,
    TRACK_STATE_VALID_LINE,
    TRACK_STATE_ALL_DARK,
    TRACK_STATE_INVALID_PATTERN
} TrackState;

typedef struct {
    int16_t left_speed;
    int16_t right_speed;
    int16_t error;
    TrackState state;
    bool line_found;
} TrackCommand;

extern volatile uint8_t g_track_pattern;
extern volatile int16_t g_track_left_speed;
extern volatile int16_t g_track_right_speed;
extern volatile TrackState g_track_state;

void track_init(void);
void track_update(void);
TrackCommand track_calculate_command(uint8_t pattern, int16_t previous_error);

#endif /* TRACK_H_ */
