#include "motor.h"

#include <stdbool.h>
#include <stdint.h>

#include "car_config.h"

static int16_t clamp_signed_speed(int32_t speed)
{
    if (speed > MOTOR_SPEED_MAX) {
        return MOTOR_SPEED_MAX;
    }
    if (speed < -MOTOR_SPEED_MAX) {
        return -MOTOR_SPEED_MAX;
    }
    return (int16_t) speed;
}

static void set_pwm(uint16_t speed, DL_TIMER_CC_INDEX cc_index)
{
    uint32_t load;
    uint32_t compare;

    if (speed > MOTOR_SPEED_MAX) {
        speed = MOTOR_SPEED_MAX;
    }

    load = DL_TimerG_getLoadValue(MOTOR_PWM_INST);
    compare = (uint32_t) (((uint64_t) load *
                          (uint32_t) (MOTOR_SPEED_MAX - speed)) /
                         MOTOR_SPEED_MAX);

    DL_TimerG_setCaptureCompareValue(
        MOTOR_PWM_INST, compare, cc_index);
}

static uint16_t set_one_motor(uint32_t in1_pin,
                              uint32_t in2_pin,
                              int16_t requested_speed,
                              uint8_t reversed)
{
    int32_t speed = clamp_signed_speed(requested_speed);
    bool backward;

    if (speed == 0) {
        DL_GPIO_clearPins(MOTOR_GPIO_PORT, in1_pin | in2_pin);
        return 0U;
    }

    backward = (speed < 0);
    if (backward) {
        speed = -speed;
    }

    if (reversed != 0U) {
        backward = !backward;
    }

    if (backward) {
        DL_GPIO_clearPins(MOTOR_GPIO_PORT, in1_pin);
        DL_GPIO_setPins(MOTOR_GPIO_PORT, in2_pin);
    } else {
        DL_GPIO_setPins(MOTOR_GPIO_PORT, in1_pin);
        DL_GPIO_clearPins(MOTOR_GPIO_PORT, in2_pin);
    }

    return (uint16_t) speed;
}

void motor_stop(void)
{
    set_pwm(0U, MOTOR_LEFT_PWM_CC);
    set_pwm(0U, MOTOR_RIGHT_PWM_CC);

    DL_GPIO_clearPins(MOTOR_GPIO_PORT,
        MOTOR_AIN1_PIN | MOTOR_AIN2_PIN |
        MOTOR_BIN1_PIN | MOTOR_BIN2_PIN |
        MOTOR_STBY_PIN);
}

void motor_init(void)
{
    motor_stop();
    DL_TimerG_startCounter(MOTOR_PWM_INST);
}

void motor_set_speeds(int16_t left_speed, int16_t right_speed)
{
    uint16_t left_pwm;
    uint16_t right_pwm;

    left_speed = clamp_signed_speed(left_speed);
    right_speed = clamp_signed_speed(right_speed);

    if ((left_speed == 0) && (right_speed == 0)) {
        motor_stop();
        return;
    }

    left_pwm = set_one_motor(
        MOTOR_AIN1_PIN, MOTOR_AIN2_PIN,
        left_speed, LEFT_MOTOR_REVERSED);
    right_pwm = set_one_motor(
        MOTOR_BIN1_PIN, MOTOR_BIN2_PIN,
        right_speed, RIGHT_MOTOR_REVERSED);

    set_pwm(left_pwm, MOTOR_LEFT_PWM_CC);
    set_pwm(right_pwm, MOTOR_RIGHT_PWM_CC);
    DL_GPIO_setPins(MOTOR_GPIO_PORT, MOTOR_STBY_PIN);
}
