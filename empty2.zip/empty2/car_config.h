#ifndef CAR_CONFIG_H_
#define CAR_CONFIG_H_

#include "ti_msp_dl_config.h"

/*
 * MSPM0G3507 + TB6612 + eight-channel grayscale board
 *
 * PWM:
 *   PB13 -> TIMG12 CCP0 -> TB6612 PWMA (left motor)
 *   PA31 -> TIMG12 CCP1 -> TB6612 PWMB (right motor)
 *
 * TB6612:
 *   PB0 -> AIN1, PB1 -> AIN2
 *   PB2 -> BIN1, PB3 -> BIN2
 *   PB4 -> STBY
 *
 * CD4051 grayscale board:
 *   PB6 -> AD0, PB7 -> AD1, PB8 -> AD2
 *   PA25 <- OUT
 */

#define MOTOR_PWM_INST                 PWM_0_INST
#define MOTOR_LEFT_PWM_CC              DL_TIMER_CC_0_INDEX
#define MOTOR_RIGHT_PWM_CC             DL_TIMER_CC_1_INDEX

#define MOTOR_GPIO_PORT                GPIOB
#define MOTOR_AIN1_PIN                 DL_GPIO_PIN_0
#define MOTOR_AIN2_PIN                 DL_GPIO_PIN_1
#define MOTOR_BIN1_PIN                 DL_GPIO_PIN_2
#define MOTOR_BIN2_PIN                 DL_GPIO_PIN_3
#define MOTOR_STBY_PIN                 DL_GPIO_PIN_4

#define GREY_SELECT_PORT               GPIOB
#define GREY_AD0_PIN                   DL_GPIO_PIN_6
#define GREY_AD1_PIN                   DL_GPIO_PIN_7
#define GREY_AD2_PIN                   DL_GPIO_PIN_8

#define GREY_OUT_PORT                  GPIOA
#define GREY_OUT_PIN                   DL_GPIO_PIN_25

/*
 * PA25's raw level when the selected probe is above white cloth.
 * Default: white cloth -> HIGH. If your actual raw reading is LOW, use 0U.
 */
#define GREY_WHITE_LEVEL               0U

/*
 * X1...X8 map to bits 0...7. X4 and X5 are the two center probes.
 * Only this exact black-line pattern is defined as centered straight travel.
 */
#define TRACK_CENTER_PATTERN           0x18U

#define LEFT_MOTOR_REVERSED            0U
#define RIGHT_MOTOR_REVERSED           0U

/* Motor command scale: 0...1000. */
#define MOTOR_SPEED_MAX                1000

/* Initial eight-channel PD parameters. */
#define TRACK_BASE_SPEED               430
#define TRACK_MAX_SPEED                750
#define TRACK_KP                       35
#define TRACK_KD                       12

/*
 * With a 32 MHz clock:
 * 32000 cycles is about 1 ms; 200 cycles lets CD4051 settle.
 */
#define TRACK_LOOP_DELAY_CYCLES        32000U
#define GREY_SETTLE_DELAY_CYCLES       200U

#endif /* CAR_CONFIG_H_ */
